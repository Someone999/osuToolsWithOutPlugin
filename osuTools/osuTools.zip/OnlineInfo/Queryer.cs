﻿namespace osuTools.Online
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    /// <summary>
    /// 代表一次在线查询，里面包含了所需的参数。
    /// </summary>
    [System.Serializable]
    public class OsuApiQuery
    {
        JArray arr;
        Uri i;
        string exc = "请检查网络是否通畅";
        public Uri QueryUri { get => i; }
        public int UserID { get; set; }
        public OsuGameMod mods;
        public OsuGameMod Mods { get { return mods; } set { if (QueryType != OsuApiQueryType.Scores) throw new ArgumentException("Mods属性只对对Scores的查询生效"); } }
        public JArray JsonArray { get => arr; }
        OsuApiType t;
        public OsuApiQueryType QueryType { get => t.ToEnum(); set => t = new OsuApiType(value); }
        OsuGameMode m = OsuGameMode.Osu;
        public OsuGameMode Mode { get => m; set => m = value; }
        string apikey;
        string user;
        public string UserName { get => user; set => user = value; }
        public int BeatmapID { get => beatmapid; set { if (value == -1) { beatmapid = 0; } else { beatmapid = value; } } }
        int lim = 0;
        /// <summary>
        /// 此属性对BestRecords(默认值10，最大值100), RecentRecords(默认值10，最大值50), Socres的查询生效(默认值50.最大值100)
        /// This property is valid for BestRecords, RecentRecords or Socres queries.Default value is 50.
        /// </summary>
        public int Limit {
            get 
            {
                return lim;
            }
            set 
            {
                if (QueryType == OsuApiQueryType.UserInfomation || QueryType == OsuApiQueryType.Beatmaps)
                    throw new ArgumentException("对于对Beatmap和User的查询，Limit属性无效。");
                if (QueryType == OsuApiQueryType.BestRecords || QueryType == OsuApiQueryType.Scores)
                    if (value > 100 || value < 1)
                        throw new ArgumentOutOfRangeException("对于对BestRecords与Scores的查询，Limit必须介于1和100之间。");
                    else lim = value;
                if(QueryType==OsuApiQueryType.RecentRecords)
                    if (value > 50 || value < 1)
                        throw new ArgumentOutOfRangeException("对于对RecentRecords的查询，Limit必须介于1和50之间。");
                    else lim = value;
            } 
        }
        public string ApiKey { get => apikey; set { if (value.Length < 40 || value.Length > 40) { apikey = ""; throw new FormatException("请输入正确的ApiKey!"); } else apikey = value; } }
        int beatmapid = -2;
        public OsuApiQuery(JArray j)
        {
            arr = j;
        }
        public OsuApiQuery()
        {

        }
        public JArray Query()
        {
            //try
            {
                string front = $"http://osu.ppy.sh/api/{t.ToString()}?k={ApiKey}";
                string after="";
                if (apikey == "")
                {
                    throw new ArgumentNullException("请输入osuAPI");
                }
                apikey = ApiKey;
                if(QueryType==OsuApiQueryType.Beatmaps)
                {
                    if (BeatmapID != -2)
                        after = $"&{BeatmapID}";
                }
                if(QueryType==OsuApiQueryType.BestRecords)
                {
                    if(UserID!=0)
                    {
                        after = $"&u={UserID}&type=id&m={(int)Mode}";
                    }
                    else
                    {
                        if(UserName!="")
                        {
                            after = $"&u={UserName}&type=string&m={(int)Mode}";
                        }
                        else
                        {
                            throw new ArgumentNullException("请指定UserName或UserID");
                        }
                    }
                    if(lim!=0)
                    {

                    }
                }
                if(QueryType==OsuApiQueryType.RecentRecords)
                {
                    if (UserID != 0)
                    {
                        after = $"&u={UserID}&type=id&m={(int)Mode}";
                    }
                    else
                    {
                        if (UserName != "")
                        {
                            after = $"&u={UserName}&type=string&m={(int)Mode}";
                        }
                        else
                        {
                            throw new ArgumentNullException("请指定UserName或UserID");
                        }
                    }
                }
                if(QueryType==OsuApiQueryType.Scores)
                {
                    if (BeatmapID == -2) throw new ArgumentNullException("请指定BeatmapID");
                    if (UserID != 0)
                    {
                        after = $"&u={UserID}&type=id&m={(int)Mode}&b={BeatmapID}";
                    }
                    else
                    {
                        if (UserName != "")
                        {
                            after = $"&u={UserName}&type=string&m={(int)Mode}&b={BeatmapID}";
                        }
                    }
                }
                Uri u = new Uri(front+after);
                i = u;
                if (u == null || i == null)
                {
                    throw new NullReferenceException("未能生成Uri");
                }
                System.Net.Http.HttpClient c = new System.Net.Http.HttpClient();
                string js = c.GetStringAsync(u).Result;

                JArray jarr = (JArray)JsonConvert.DeserializeObject(js);
                arr = jarr;
                if (QueryType == OsuApiQueryType.Beatmaps)
                {
                    exc += $"并检查谱面ID({beatmapid})是否正确。";
                }
                if (QueryType == OsuApiQueryType.BestRecords || QueryType == OsuApiQueryType.Scores || QueryType == OsuApiQueryType.RecentRecords)
                {
                    exc += $"并检查用户名({user})谱面ID({beatmapid})是否正确。";
                }
                if (QueryType == OsuApiQueryType.UserInfomation)
                {
                    exc += $"并检查用户名({user})是否正确。";
                }
                if (jarr.Count == 0)
                {
                    if ((QueryType != OsuApiQueryType.RecentRecords || QueryType != OsuApiQueryType.BestRecords || QueryType != OsuApiQueryType.Scores))
                    {

                    }
                    else
                    {
                        throw new osuToolsException.OnlineQueryFailed($"{exc}");
                    }
                }
                return jarr;
            }
            // catch (Exception c)
            {
                //Sync.Tools.IO.CurrentIO.WriteColor($"查询失败:{c.Message}", ConsoleColor.Red);
                return new JArray();
            }

        }
    }
}