﻿namespace osuTools
{
    namespace Online
    {

        using Newtonsoft.Json;
        using Newtonsoft.Json.Linq;
        using System;
        using System.Collections.Generic;
        using System.IO;
        /// <summary>
        /// 存储最高PP榜指定数量的记录，最多100个。
        /// </summary>
        public class OnlineBestRecordCollection : OnlineInfo<OnlineBestRecord>
        {
            List<OnlineBestRecord> records = new List<OnlineBestRecord>();
            public IReadOnlyList<OnlineBestRecord> Records { get => records.AsReadOnly(); }
            OsuApiQuery q;
            public bool Failed { get; private set; }
            public void Update()
            {
                records.Clear();
                AllParse(q);
            }
            public OnlineBestRecord this[int x]
            {
                get => records[x];
            }
            public OnlineBestRecordCollection()
            {
                
            }
            public void AllParse(OsuApiQuery query)
            {
                if (query.QueryType != OsuApiQueryType.BestRecords)
                {
                    throw new ArgumentException("请使用OsuApiQueryType.BestRecords来获取最佳纪录!");
                }
                var j = query.Query();
                if (j.Count == 0)
                {
                    Failed = true;
                    records.Add(new OnlineBestRecord());
                    return;
                }
               for(int i=0;i<j.Count;i++)
                {
                    var r = new OnlineBestRecord(j[i].ToString());
                    r.CalcWeight(i);
                    records.Add(r);
                }
                q = query;
            }
            public IEnumerator<OnlineBestRecord> GetEnumerator()
            {
                return records.GetEnumerator();
            }
        }
        /// <summary>
        /// 最高PP榜中的记录
        /// </summary>
        [Serializable]
        public partial class OnlineBestRecord :PPSorted
        {

            bool per;
            bool findInit = false;
            Beatmaps.BeatmapCollection BC;
            DateTime d;
            public List<OsuGameMod> Mods { get; } = new List<OsuGameMod>();
            int mods;
            uint
            beatmap_id,
            score_id;
            double pp,wpp;
            int
            score,
            maxcombo,
            count50,
            count100,
            count300,
            countmiss,
            countkatu,
            countgeki,
            perfect,
            user_id;
            string
            date,
            rank;
            public OnlineBestRecord()
            {
                per = false;
                d = DateTime.MinValue;
                beatmap_id = 0;
                score_id = 0;
                score = 0;
                pp = 0.0;
                wpp = 0.0;
                maxcombo = 0;
                count300 = 0;
                count100 = 0;
                count50 = 0;
                countgeki = 0;
                countkatu = 0;
                countmiss = 0;
                perfect = 0;
                user_id = 0;
                date = "0-0-0 0:0:0";
                Mods = Tools.OsuGameModTools.Parse(mods);
                rank = "?";
            }
            internal void CalcWeight(int rank)
            {
                wpp = pp * (Math.Pow(0.95, rank));
            }
            public OnlineBestRecord(string json)
            {

                var jobj = (JObject)(JsonConvert.DeserializeObject(json));
                int.TryParse(jobj["countgeki"].ToString(), out countgeki);
                int.TryParse(jobj["countkatu"].ToString(), out countkatu);
                int.TryParse(jobj["count300"].ToString(), out count300);
                int.TryParse(jobj["count100"].ToString(), out count100);
                int.TryParse(jobj["count50"].ToString(), out count50);
                int.TryParse(jobj["countmiss"].ToString(), out countmiss);
                int.TryParse(jobj["maxcombo"].ToString(), out maxcombo);
                int.TryParse(jobj["score"].ToString(), out score);
                int.TryParse(jobj["user_id"].ToString(), out user_id);
                int.TryParse(jobj["perfect"].ToString(), out perfect);
                uint.TryParse(jobj["beatmap_id"].ToString(), out beatmap_id);
                uint.TryParse(jobj["score_id"].ToString(), out score_id);
                double.TryParse(jobj["pp"].ToString(), out pp);
                date = jobj["date"].ToString();
                rank = jobj["rank"].ToString();
                Mods = Tools.OsuGameModTools.Parse(mods);
                DateTime.TryParse(date, out d);
                if (perfect == 1)
                {
                    per = true;
                }
                else if (perfect == 0)
                {
                    per = false;
                }
            }
            public Beatmaps.Beatmap GetBeatmap()
            {
                Beatmaps.Beatmap b = new Beatmaps.Beatmap();
                OnlineBeatmapCollection bms = new OnlineBeatmapCollection();
                OsuApiQuery q = new OsuApiQuery();
                string osuApiKey = "fa2748650422c84d59e0e1d5021340b6c418f62f";
                q.ApiKey = osuApiKey;
                q.BeatmapID = (int)beatmap_id;
                q.QueryType = OsuApiQueryType.Beatmaps;
                bms.AllParse(q);
                b = new Beatmaps.Beatmap(bms[0]);
                return b;
            }
            public OnlineBeatmap GetOnlineBeatmap()
            {
                OnlineBeatmapCollection bms = new OnlineBeatmapCollection();
                OsuApiQuery q = new OsuApiQuery();
                string osuApiKey = "fa2748650422c84d59e0e1d5021340b6c418f62f";
                q.QueryType = OsuApiQueryType.Beatmaps;
                q.ApiKey = osuApiKey;
                q.BeatmapID = (int)beatmap_id;
                bms.AllParse(q);
                return bms[0];
            }
            System.Threading.Tasks.Task findbeatmaptask;

            public Beatmaps.Beatmap FindInBeatmapCollection(Beatmaps.BeatmapCollection bc)
            {

                if (bc is null) throw new NullReferenceException();
                BC = bc;
                return bc.Find((int)beatmap_id);
            }
            public override string ToString()
            {
                try
                {
                    if (BC == null)
                        return $"{beatmap_id}\nScore:{Score} PP:{PP}\nc300g:{c300g} c300:{c300} c200:{c200} c100:{c100} c50:{c50} cMiss:{cMiss} MaxCombo:{MaxCombo}\nPerfect:{Perfect}";
                    else
                    {
                        var v = FindInBeatmapCollection(BC);
                        if (v == null) throw new NullReferenceException();
                        return $"{v.ToString()}\nScore:{Score} PP:{PP}\nc300g:{c300g} c300:{c300} c200:{c200} c100:{c100} c50:{c50} cMiss:{cMiss} MaxCombo:{MaxCombo}\nPerfect:{Perfect}";
                    }
                }
                catch
                {

                    return "操作失败";
                }
            }
            public void WriteToFile(string filename = "")
            {
                if (filename == "")
                {
                    //filename=$"{}"
                }
                string datatowrite = $"{user_id}?{beatmap_id}?{pp}?{score}?{c300g}?{c300}?{c200}?{c100}?{c50}?{cMiss}?{MaxCombo}?{Perfect}";
            }
            public static OnlineBestRecord Parse(string str)
            {
                OnlineBestRecord b = new OnlineBestRecord();
                string[] data = str.Split('?');
                if (data.Length != 12) {System.Diagnostics.Debug.WriteLine("输入的字符串格式不正确"); }
                b.user_id = int.Parse(data[0]);
                b.beatmap_id = uint.Parse(data[1]);
                b.pp = double.Parse(data[2]);
                b.score = int.Parse(data[3]);
                b.countgeki = int.Parse(data[4]);
                b.count300 = int.Parse(data[5]);
                b.countkatu = int.Parse(data[6]);
                b.count100 = int.Parse(data[7]);
                b.count50 = int.Parse(data[8]);
                b.countmiss = int.Parse(data[9]);
                b.maxcombo = int.Parse(data[10]);
                b.per = bool.Parse(data[11]);
                return b;
            }
        }
    }
}