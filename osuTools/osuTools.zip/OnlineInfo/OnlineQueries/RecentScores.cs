﻿namespace osuTools
{
    namespace Online
    {
        using Newtonsoft.Json;
        using Newtonsoft.Json.Linq;
        using System;
        using System.Collections.Generic;
        /// <summary>
        /// 存储最近24小时打出所有成绩
        /// </summary>
        public class RecentOnlineResultCollection : OnlineInfo<RecentOnlineResult>
        {
            int x = 0;
            List<RecentOnlineResult> results = new List<RecentOnlineResult>();
            int p = -1;
            public bool Failed { get; private set; } = false;
            public IEnumerator<RecentOnlineResult> GetEnumerator()
            {
                return results.GetEnumerator();
            }
            public RecentOnlineResult this[int x]
            {
                get => results[x];
            }
            public List<RecentOnlineResult> RecentResults { get => results; }
            public RecentOnlineResultCollection()
            {
                
            }
            public void AllParse(OsuApiQuery query)
            {
                if (query.QueryType != OsuApiQueryType.RecentRecords)
                {
                    throw new ArgumentException("请用OsuApiQueryType.RecentRecords获取最近的记录!");
                }
                var ja = query.Query();
                if (ja.Count == 0)
                {
                    Failed = true;
                    results.Add(new RecentOnlineResult());
                    return;
                }
                foreach (var js in ja)
                {
                    results.Add(new RecentOnlineResult(js.ToString(),query.Mode));
                }
            }
        }
        /// <summary>
        /// 最近24小时打出的成绩
        /// </summary>
        [Serializable]
        public partial class RecentOnlineResult:ScoreSorted,IComparable<RecentOnlineResult>
        {
            bool per;
            DateTime d;
            public List<OsuGameMod> Mods { get; } = new List<OsuGameMod>();
            uint
            beatmap_id;
            int score;
            int mod;
            int
            maxcombo,
            count50,
            count100,
            count300,
            countmiss,
            countkatu,
            countgeki,
            perfect,
            user_id;
            string
            date,
            rank;
            double acc;
            public OsuGameMode Mode { get; private set; }
            public double Accuracy { get; private set; }
            public int CompareTo(RecentOnlineResult r)
            {
                if (score > r.score) return -1;
                if (score == r.score) return 0;
                if (score < r.score) return 1;
                return 0;
            }
            public RecentOnlineResult()
            {
                per = false;
                d = DateTime.MinValue;
                beatmap_id = 0;
                score = 0;
                mod = 0;
                maxcombo = 0;
                Mods = Tools.OsuGameModTools.Parse(mod);
                count300 = 0;
                count100 = 0;
                count50 = 0;
                countgeki = 0;
                countkatu = 0;
                countmiss = 0;
                perfect = 0;
                user_id = 0;
                date = "0-0-0 0:0:0";
                rank = "?";
            }
            double AccCalc(OsuGameMode mode)
            {
                double c3g = c300g,c3=c300,c2=c200,c1=c100,c5=c50,cm=cMiss;
                double a3g = 1, a3 = 1, a2 = (2.0 / 3), a1 = (1.0 / 3), a5 = (1.0 / 6);
                double mall = c3 + c3g + c2 + c1 + c5 + cm;
                double sall = c3 + c1 + c5 + cm;
                double call = c3 + c1 + c2 + c5 + cm;
                double tall = c3 + c1 + cm;
                switch(mode)
                {
                    case OsuGameMode.Catch:return (c3 + c1 + c5) / call;
                    case OsuGameMode.Osu:return (c3 + c1*a1 + c5*a5) / sall;
                    case OsuGameMode.Taiko:return (c3 + c3g + (c1 + c2) * a1) / tall;
                    case OsuGameMode.Mania:return (c3 + c3g + c2 * a2 + c1 * a1 + c5 * a5) / mall;
                    default: return 0;
                }
            }
            public RecentOnlineResult(string json,OsuGameMode mode)
            {
                Mode = mode;
                var jobj = (JObject)(JsonConvert.DeserializeObject(json));              
                int.TryParse(jobj["countgeki"].ToString(), out countgeki);
                int.TryParse(jobj["countkatu"].ToString(), out countkatu);
                int.TryParse(jobj["count300"].ToString(), out count300);
                int.TryParse(jobj["count100"].ToString(), out count100);
                int.TryParse(jobj["count50"].ToString(), out count50);
                int.TryParse(jobj["countmiss"].ToString(), out countmiss);
                int.TryParse(jobj["maxcombo"].ToString(), out maxcombo);
                int.TryParse(jobj["score"].ToString(), out score);
                int.TryParse(jobj["user_id"].ToString(), out user_id);
                int.TryParse(jobj["perfect"].ToString(), out perfect);
                int.TryParse(jobj["enabled_mods"].ToString(), out mod);
                Mods = Tools.OsuGameModTools.Parse(mod);
                uint.TryParse(jobj["beatmap_id"].ToString(), out beatmap_id);                
                date = jobj["date"].ToString();
                rank = jobj["rank"].ToString();
                DateTime.TryParse(date, out d);
                DateTime e;
                e=TimeZone.CurrentTimeZone.ToLocalTime(d);
                d = e;
                if (perfect == 1)
                {
                    per = true;
                }
                else if (perfect == 0)
                {
                    per = false;
                }
                acc = AccCalc(Mode);
            }
           
        }
    }
}