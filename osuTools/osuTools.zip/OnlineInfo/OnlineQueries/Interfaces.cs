﻿namespace osuTools
{
    namespace Online
    {
        public interface OnlineInfo<T>
        {
            void AllParse(OsuApiQuery query);
        }
       
        public abstract class ScoreSorted : System.IComparable<ScoreSorted>
        {
            public virtual int Score { get; }
            public int CompareTo(ScoreSorted s)
            {
                if (Score > s.Score) return -1;
                if (Score < s.Score) return 1;
                if (Score == s.Score) return 0;
                return 0;
            }
            static public bool operator >(ScoreSorted a,ScoreSorted b)
            {
                return a.Score > b.Score;
            }
            static public bool operator <(ScoreSorted a, ScoreSorted b)
            {
                return a.Score < b.Score;
            }
            static public bool operator ==(ScoreSorted a, ScoreSorted b)
            {
                return a.Score == b.Score;
            }
            static public bool operator !=(ScoreSorted a, ScoreSorted b)
            {
                return a.Score != b.Score;
            }

        }
       
        public abstract class PPSorted : System.IComparable<PPSorted>
        {
            public virtual double PP { get; }
            static public bool operator >(PPSorted a, PPSorted b)
            {
                return a.PP > b.PP;
            }
            static public bool operator <(PPSorted a, PPSorted b)
            {
                return a.PP < b.PP;
            }
            static public bool operator ==(PPSorted a, PPSorted b)
            {
                return a.PP == b.PP;
            }
            static public bool operator !=(PPSorted a, PPSorted b)
            {
                return a.PP != b.PP;
            }
            public int CompareTo(PPSorted s)
            {
                if (PP > s.PP) return -1;
                if (PP < s.PP) return 1;
                if (PP == s.PP) return 0;
                return 0;
            }

        }
    }
}