﻿namespace osuTools
{
    namespace Online
    {
        using Newtonsoft.Json;
        using Newtonsoft.Json.Linq;
        using System;
        using System.Collections.Generic;
        /// <summary>
        /// 获取一个谱面排行榜上最高100个记录。
        /// </summary>
        public class OnlineScoreCollection : OnlineInfo<OnlineScore>
        {
            List<OnlineScore> r = new List<OnlineScore>();
            int enumpos = -1;
            int x = 0;
            OnlineScore bs;
            public bool Failed { get; private set; } = false;
            public OnlineScore BestScore { get => bs; }
            public List<OnlineScore> Scores { get => r; }
            public void AllParse(OsuApiQuery q)
            {
                if (q.QueryType != OsuApiQueryType.Scores)
                {
                    throw new ArgumentException("请用OsuApiQueryType.Scores获取分数记录!");
                }
                var ja = q.Query();
                if (ja.Count == 0)
                {
                    Failed = true;
                    r.Add(new OnlineScore());
                    return;
                }
                foreach (var js in ja)
                {
                    r.Add(new OnlineScore(js.ToString()));
                }
                if (r.Count == 1 && !Failed)
                    bs = r[0];
                else
                {
                    r.Sort();
                }
            }
            public IEnumerator<OnlineScore> GetEnumerator()
            {
                return Scores.GetEnumerator();
            }

        }
        /// <summary>
        /// 一个谱面的最高100个记录之一。
        /// </summary>
        [Serializable]
        public partial class OnlineScore :PPSorted
        {
            bool per, rep;
            DateTime d;
            uint
            score_id;
            public List<OsuGameMod> Mods { get; } = new List<OsuGameMod>();
            int score, replay_available;
            double pp;
            int mod;
            int
            maxcombo,
            count50,
            count100,
            count300,
            countmiss,
            countkatu,
            countgeki,
            perfect,
            user_id;
            string
            date,
            rank;
            public override string ToString()
            {
                return $"{UserID} {PP} {Score}";
            }
            public OnlineScore()
            {
                replay_available = 0;
                per = false;
                d = DateTime.MinValue;
                rep = false;
                score_id = 0;
                score = 0;
                pp = 0.0;
                maxcombo = 0;
                count300 = 0;
                count100 = 0;
                count50 = 0;
                countgeki = 0;
                countkatu = 0;
                countmiss = 0;
                perfect = 0;
                user_id = 0;
                date = "0-0-0 0:0:0";
                rank = "?";
                Mods = Tools.OsuGameModTools.Parse(mod);
            }
            public OnlineScore(string json)
            {
                //try
                {
                    var jobj = JsonConvert.DeserializeObject(json);
                    var cjobj = new JObject();
                    if(jobj.GetType()==typeof(JObject))
                    {
                        cjobj = (JObject)jobj;
                    }
                    if (jobj.GetType() == typeof(JArray))
                    {
                        cjobj = (JObject)((JArray)jobj)[0];
                    }

                    int.TryParse(cjobj["countgeki"].ToString(), out countgeki);
                    int.TryParse(cjobj["countkatu"].ToString(), out countkatu);
                    int.TryParse(cjobj["count300"].ToString(), out count300);
                    int.TryParse(cjobj["count100"].ToString(), out count100);
                    int.TryParse(cjobj["count50"].ToString(), out count50);
                    int.TryParse(cjobj["countmiss"].ToString(), out countmiss);
                    int.TryParse(cjobj["maxcombo"].ToString(), out maxcombo);
                    int.TryParse(cjobj["score"].ToString(), out score);
                    int.TryParse(cjobj["user_id"].ToString(), out user_id);
                    int.TryParse(cjobj["perfect"].ToString(), out perfect);
                    int.TryParse(cjobj["replay_available"].ToString(), out replay_available);
                    uint.TryParse(cjobj["score_id"].ToString(), out score_id);
                    double.TryParse(cjobj["pp"].ToString(), out pp);
                    date = cjobj["date"].ToString();
                    rank = cjobj["rank"].ToString();
                    Mods = Tools.OsuGameModTools.Parse(mod);
                    DateTime.TryParse(date, out d);
                    if (perfect == 1)
                    {
                        per = true;
                    }
                    else if (perfect == 0)
                    {
                        per = false;
                    }
                    if (replay_available == 1)
                    {
                        rep = true;
                    }
                    else
                    {
                        rep = false;
                    }
                }
               /* catch
                {
                    replay_available = 0;
                    per = false;
                    d = DateTime.MinValue;
                    rep = false;
                    score_id = 0;
                    score = 0;
                    pp = 0.0;
                    maxcombo = 0;
                    count300 = 0;
                    count100 = 0;
                    count50 = 0;
                    countgeki = 0;
                    countkatu = 0;
                    countmiss = 0;
                    perfect = 0;
                    user_id = 0;
                    date = "0-0-0 0:0:0";
                    rank = "?";
                }*/
            }
        }
    }
}