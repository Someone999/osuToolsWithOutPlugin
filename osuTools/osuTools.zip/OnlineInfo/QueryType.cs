﻿namespace osuTools
{
    namespace Online
    {
        [System.Serializable]
        public enum OsuApiQueryType { UserInfomation, BestRecords, RecentRecords, Beatmaps, Scores, Unknown }
        [System.Serializable]
        class OsuApiType
        {
            string Type;
            System.Uri u;
            public static OsuApiType GetUserInfomation = new OsuApiType("get_user");
            public static OsuApiType GetBestRecords = new OsuApiType("get_user_best");
            public static OsuApiType GetRecentRecords = new OsuApiType("get_user_recent");
            public static OsuApiType GetBeatmaps = new OsuApiType("get_beatmaps");
            public static OsuApiType GetBeatmapBestRecords = new OsuApiType("get_user_best");
            public static OsuApiType GetScores = new OsuApiType("get_scores");

            private OsuApiType(string type)
            {

                //if (type == "get_user" || type == "get_user_best" || type == "get_user_recent" || type == "get_beatmaps"||type!= "get_scores")
                {
                    Type = type;
                }
                /*else
                {
                    throw new System.FormatException("无法获取\"" + type + "\"的信息");
                }*/
            }
            public OsuApiQueryType ToEnum()
            {
                return Type == "get_user" ? OsuApiQueryType.UserInfomation :
                    Type == "get_user_best" ? OsuApiQueryType.BestRecords :
                    Type == "get_user_recent" ? OsuApiQueryType.RecentRecords :
                    Type == "get_scores" ? OsuApiQueryType.Scores :
                    Type == "get_beatmaps" ? OsuApiQueryType.Beatmaps :
                    OsuApiQueryType.Unknown;
            }
            public OsuApiType(OsuApiQueryType type)
            {
                switch (type)
                {
                    case OsuApiQueryType.BestRecords: Type = GetBeatmapBestRecords.ToString(); break;
                    case OsuApiQueryType.UserInfomation: Type = GetUserInfomation.ToString(); break;
                    case OsuApiQueryType.Beatmaps: Type = GetBeatmaps.ToString(); break;
                    case OsuApiQueryType.RecentRecords: Type = GetRecentRecords.ToString(); break;
                    case OsuApiQueryType.Scores: Type = GetScores.ToString(); break;
                    case OsuApiQueryType.Unknown: Type = ""; break;
                }
            }
            public override string ToString()
            {
                return Type;
            }
        }
    }
}