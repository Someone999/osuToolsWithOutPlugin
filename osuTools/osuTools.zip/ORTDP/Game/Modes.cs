﻿namespace osuTools
{
   
    namespace Tools
    {
        public static class OsuGameModeTools
        {
            public static OsuGameMode Parse(string mode)
            {
                if (string.Compare(mode, "mania", true) == 0) return OsuGameMode.Mania;
                if (string.Compare(mode, "osu", true) == 0) return OsuGameMode.Osu;
                if (string.Compare(mode, "catch", true) == 0 || string.Compare(mode, "Ctb", true) == 0) return OsuGameMode.Catch;
                if (string.Compare(mode, "taiko", true) == 0) return OsuGameMode.Taiko;
                return OsuGameMode.Unkonwn;
            }
            public static OsuGameMode Parse(int mode)
            {
                switch (mode)
                {
                    case 0:return OsuGameMode.Osu;
                    case 1:return OsuGameMode.Taiko;
                    case 2:return OsuGameMode.Catch;
                    case 3:return OsuGameMode.Mania;
                    default:return OsuGameMode.Unkonwn;
                }
            }
        }
    }
}
