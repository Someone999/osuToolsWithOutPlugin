﻿namespace osuTools
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    namespace Tools
    {
        public class OsuGameModTools
        {
            public static List<OsuGameMod> Parse(int Mods)
            {
                List<OsuGameMod> lst = new List<OsuGameMod>();
                if (Mods == 0)
                {
                    lst.Add(OsuGameMod.None);
                    return lst;
                }
                #region Mods
                bool HasAuto = (Mods & (int)OsuGameMod.AutoPlay) != 0
                    , HasCinema = (Mods & (int)OsuGameMod.Cinema) != 0
                    , HasAutoOrCinema = HasAuto || HasCinema
                    , HasNoFail = (Mods & (int)(OsuGameMod.NoFail)) != 0
                    , HasSuddenDeath = (Mods & (int)(OsuGameMod.SuddenDeath)) != 0
                    , HasPerfect = (Mods & (int)(OsuGameMod.Perfect)) != 0
                    , HasSuddenDeathOrPerfect = HasSuddenDeath || HasPerfect
                    , HasRelax = (Mods & (int)(OsuGameMod.Relax)) != 0
                    , HasAutoPilot = (Mods & (int)(OsuGameMod.AutoPilot)) != 0
                    , HasSpunOut = (Mods & (int)(OsuGameMod.SpunOut)) != 0
                    , HasRelaxMod = HasAutoPilot || HasRelax || HasSpunOut
                    , HasEasy = (Mods & (int)(OsuGameMod.Easy)) != 0
                    , HasHardRock = (Mods & (int)(OsuGameMod.HardRock)) != 0
                    , HasDoubleTime = (Mods & (int)(OsuGameMod.DoubleTime)) != 0
                    , HasNightCore = (Mods & (int)(OsuGameMod.NightCore)) != 0
                    , HasDoubleTimeOrNightCore = (Mods & (int)(OsuGameMod.DoubleTime)) != 0 || (Mods & (int)(OsuGameMod.NightCore)) != 0
                    , HasHalfTime = (Mods & (int)(OsuGameMod.HalfTime)) != 0
                    , HasFadeIn = (Mods & (int)(OsuGameMod.FadeIn)) != 0
                    , HasFlashlight = (Mods & (int)(OsuGameMod.Flashlight)) != 0
                    , HasHidden = (Mods & (int)(OsuGameMod.Hidden)) != 0;
                #endregion
                #region Invalid Combination
                bool IsInvalidConbination = HasAutoOrCinema && HasRelaxMod ||
                    HasAutoOrCinema && HasSuddenDeathOrPerfect ||
                    HasNoFail && HasSuddenDeathOrPerfect ||
                    HasEasy && HasHardRock ||
                    HasHalfTime && HasDoubleTimeOrNightCore ||
                    HasFadeIn && HasFlashlight ||
                    HasFadeIn && HasHidden;
                #endregion
                if (IsInvalidConbination)
                {
                    System.Windows.Forms.MessageBox.Show("Mod组合无效。", "错误", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
                    return lst;
                }
                double mods = Mods;
                double lg2 = Math.Log(mods, 2);
                double lg2int = Math.Truncate(lg2);
                var arr = (OsuGameMod[])Enum.GetValues(typeof(OsuGameMod));
                while (lg2 != lg2int)
                {
                    var value = Math.Pow(2, lg2int);
                    mods -= value;
                    lg2 = Math.Log(mods, 2);
                    lg2int = Math.Truncate(lg2);
                    OsuGameMod vmod = (OsuGameMod)value;
                    if (!arr.Contains(vmod))
                    {
                        lst.Add(OsuGameMod.Unknown);
                    }
                    #region Conflicting Mods                   
                    if (vmod == OsuGameMod.HalfTime)
                        if (!lst.Contains(OsuGameMod.DoubleTime) && !lst.Contains(OsuGameMod.NightCore))
                            lst.Add(vmod);
                    if (vmod == OsuGameMod.NoFail)
                        if (!lst.Contains(OsuGameMod.SuddenDeath) && !lst.Contains(OsuGameMod.Perfect))
                            lst.Add(vmod);
                    if (vmod == OsuGameMod.Easy)
                        if (!lst.Contains(OsuGameMod.HardRock))
                            lst.Add(vmod);
                    if (vmod == OsuGameMod.Relax)
                        if (!lst.Contains(OsuGameMod.AutoPilot))
                            lst.Add(vmod);
                    #endregion
                    #region DT Inviad Combination
                    if (vmod == OsuGameMod.NightCore)
                        if (!lst.Contains(OsuGameMod.DoubleTime))
                            lst.Add(vmod);
                    if (vmod == OsuGameMod.DoubleTime)
                        if (!lst.Contains(OsuGameMod.NightCore))
                            lst.Add(vmod);
                    #endregion
                    #region Auto Ivalid Combination
                    if (vmod == OsuGameMod.AutoPlay || vmod == OsuGameMod.Cinema)
                        if (!lst.Contains(OsuGameMod.AutoPilot) && !lst.Contains(OsuGameMod.Relax) && !lst.Contains(OsuGameMod.SuddenDeath) && !lst.Contains(OsuGameMod.Perfect) && !lst.Contains(OsuGameMod.SpunOut))
                            lst.Add(vmod);
                    if (vmod == OsuGameMod.Cinema)
                        if (!lst.Contains(OsuGameMod.AutoPlay))
                            lst.Add(vmod);
                    if (vmod == OsuGameMod.AutoPlay)
                        if (!lst.Contains(OsuGameMod.Cinema))
                            lst.Add(vmod);
                    #endregion
                    #region PF Invalid Combination
                    if (vmod == OsuGameMod.Perfect)
                        if (!lst.Contains(OsuGameMod.SuddenDeath))
                            lst.Add(vmod);
                    if (vmod == OsuGameMod.SuddenDeath)
                        if (!lst.Contains(OsuGameMod.Perfect))
                            lst.Add(vmod);
                    #endregion
                    #region HD Invlid Combination
                    if (vmod == OsuGameMod.Hidden)
                        if (!lst.Contains(OsuGameMod.FadeIn))
                            lst.Add(vmod);
                    if (vmod == OsuGameMod.FadeIn)
                        if (!lst.Contains(OsuGameMod.Hidden))
                            lst.Add(vmod);
                    #endregion
                    if (!lst.Contains(vmod))
                        lst.Add(vmod);

                    if (lg2 == lg2int) break;
                }
                #region NotUsed
                /*  OsuGameMod gm = (OsuGameMod)mods;
                  #region Invalid Mod Conbination
                  if (gm != OsuGameMod.None)
                  {
                      if (gm == OsuGameMod.Cinema)
                          if (!lst.Contains(OsuGameMod.AutoPlay))
                              lst.Add((OsuGameMod)mods);
                      if (gm == OsuGameMod.AutoPlay)
                          if (!lst.Contains(OsuGameMod.Cinema))
                              lst.Add(gm);
                      if (gm == OsuGameMod.DoubleTime)
                          if (!lst.Contains(OsuGameMod.NightCore))
                              lst.Add(gm);
                      if (gm == OsuGameMod.NightCore)
                          if (!lst.Contains(OsuGameMod.DoubleTime))
                              lst.Add(gm);
                      if (gm == OsuGameMod.SuddenDeath)
                          if (!lst.Contains(OsuGameMod.Perfect))
                              lst.Add(gm);
                      if (gm == OsuGameMod.Perfect)
                          if (!lst.Contains(OsuGameMod.SuddenDeath))
                              lst.Add(gm);
                  }*/
                  #endregion
                return lst;
            }
        }
    }

    [System.Serializable]
    public partial class GMMod
    {
        List<OsuGameModA> mods = new List<OsuGameModA>();
        public GMMod(string modstr)
        {
            string[] modsplit = modstr.Split(',');
            for (int i = 0; i < modsplit.Length; i++)
            {
                this.mods.Add(new OsuGameModA(modsplit[i].Trim()));
            }
        }
        public override string ToString()
        {
            string AllMod = "";
            foreach (OsuGameModA mod in mods)
            {
                // AllMod += mod.ToString() + " ";
            }
            return AllMod;
        }
        public bool HasMod(OsuGameMod m)
        {
            foreach (OsuGameModA mod in mods)
            {
                if (mod.Mod.ToEnum() == m)
                {
                    return true;
                }
            }
            return false;
        }

    }
    [System.Serializable]
    class OsuGameModA
    {
        string mod = "???";
        string longmod = "???";
        int intmod = -1;
        public OsuGameModA Mod { get; }
        public OsuGameModA(string x)
        {
            if (x == "EZ") { longmod = "Easy"; mod = x; intmod = 1; }
            if (x == "HT") { longmod = "HalfTime"; mod = x; intmod = 2; }
            if (x == "NF") { longmod = "NoFail"; mod = x; intmod = 3; }
            if (x == "HR") { longmod = "HardRock"; mod = x; intmod = 4; }
            if (x == "SD") { longmod = "SuddenDeath"; mod = x; intmod = 5; }
            if (x == "PF") { longmod = "Perfect"; mod = x; intmod = 6; }
            if (x == "DT") { longmod = "DoubleTime"; mod = x; intmod = 7; }
            if (x == "NC") { longmod = "NightCore"; mod = x; intmod = 8; }
            if (x == "HD") { longmod = "Hidden"; mod = x; intmod = 9; }
            if (x == "FI") { longmod = "FadeIn"; mod = x; intmod = 10; }
            if (x == "FL") { longmod = "Flashlight"; mod = x; intmod = 11; }
            if (x == "1K") { longmod = "Key1"; mod = x; intmod = 12; }
            if (x == "2K") { longmod = "Key2"; mod = x; intmod = 13; }
            if (x == "3K") { longmod = "Key3"; mod = x; intmod = 14; }
            if (x == "4K") { longmod = "Key4"; mod = x; intmod = 15; }
            if (x == "5K") { longmod = "Key5"; mod = x; intmod = 16; }
            if (x == "6K") { longmod = "Key6"; mod = x; intmod = 17; }
            if (x == "7K") { longmod = "Key7"; mod = x; intmod = 18; }
            if (x == "8K") { longmod = "Key8"; mod = x; intmod = 19; }
            if (x == "9K") { longmod = "Key9"; mod = x; intmod = 20; }
            if (x == "Co-op") { longmod = "KeyCoop"; mod = x; intmod = 21; }
            if (x == "RD") { longmod = "Random"; mod = x; intmod = 22; }
            if (x == "Auto") { longmod = "AutoPlay"; mod = x; intmod = 23; }
            if (x == "CN") { longmod = "Cinema"; mod = x; intmod = 24; }
            if (x == "V2") { longmod = "SocreV2"; mod = x; intmod = 25; }
            if (x == "RL") { longmod = "Relax"; mod = x; intmod = 26; }
            if (x == "AP") { longmod = "AutoPilot"; mod = x; intmod = 27; }
            if (x == "SO") { longmod = "SpunOut"; mod = x; intmod = 28; }
            if (x == "Unknown") { longmod = "Unknown"; mod = "Unknown"; intmod = 29; }


        }
        public OsuGameModA(OsuGameMod x)
        {
            if (x == OsuGameMod.Easy) { longmod = "Easy"; mod = "EZ"; intmod = 1; }
            if (x == OsuGameMod.HalfTime) { longmod = "HalfTime"; mod = "HT"; intmod = 2; }
            if (x == OsuGameMod.NoFail) { longmod = "NoFail"; mod = "NF"; intmod = 3; }
            if (x == OsuGameMod.HardRock) { longmod = "HardRock"; mod = "HR"; intmod = 4; }
            if (x == OsuGameMod.SuddenDeath) { longmod = "SuddenDeath"; mod = "SD"; intmod = 5; }
            if (x == OsuGameMod.Perfect) { longmod = "Perfect"; mod = "PF"; intmod = 6; }
            if (x == OsuGameMod.DoubleTime) { longmod = "DoubleTime"; mod = "DT"; intmod = 7; }
            if (x == OsuGameMod.NightCore) { longmod = "NightCore"; mod = "NC"; intmod = 8; }
            if (x == OsuGameMod.Hidden) { longmod = "Hidden"; mod = "HD"; intmod = 9; }
            if (x == OsuGameMod.FadeIn) { longmod = "FadeIn"; mod = "FI"; intmod = 10; }
            if (x == OsuGameMod.Flashlight) { longmod = "Flashlight"; mod = "FL"; intmod = 11; }
            if (x == OsuGameMod.Key1) { longmod = "Key1"; mod = "1K"; intmod = 12; }
            if (x == OsuGameMod.Key2) { longmod = "Key2"; mod = "2K"; intmod = 13; }
            if (x == OsuGameMod.Key3) { longmod = "Key3"; mod = "3K"; intmod = 14; }
            if (x == OsuGameMod.Key4) { longmod = "Key4"; mod = "4K"; intmod = 15; }
            if (x == OsuGameMod.Key5) { longmod = "Key5"; mod = "5K"; intmod = 16; }
            if (x == OsuGameMod.Key6) { longmod = "Key6"; mod = "6K"; intmod = 17; }
            if (x == OsuGameMod.Key7) { longmod = "Key7"; mod = "7K"; intmod = 18; }
            if (x == OsuGameMod.Key8) { longmod = "Key8"; mod = "8K"; intmod = 19; }
            if (x == OsuGameMod.Key9) { longmod = "Key9"; mod = "9K"; intmod = 20; }
            if (x == OsuGameMod.KeyCoop) { longmod = "KeyCoop"; mod = "Co-op"; intmod = 21; }
            if (x == OsuGameMod.Random) { longmod = "Random"; mod = "RD"; intmod = 22; }
            if (x == OsuGameMod.AutoPlay) { longmod = "AutoPlay"; mod = "Auto"; intmod = 23; }
            if (x == OsuGameMod.Cinema) { longmod = "Cinema"; mod = "CN"; intmod = 24; }
            if (x == OsuGameMod.ScoreV2) { longmod = "SocreV2"; mod = "V2"; intmod = 25; }
            if (x == OsuGameMod.Relax) { longmod = "Relax"; mod = "RL"; intmod = 26; }
            if (x == OsuGameMod.AutoPilot) { longmod = "AutoPilot"; mod = "AP"; intmod = 27; }
            if (x == OsuGameMod.SpunOut) { longmod = "SpunOut"; mod = "SO"; intmod = 28; }
            if (x == OsuGameMod.Unknown) { longmod = "Unknown"; mod = "Unknown"; intmod = 29; }

        }
        public OsuGameMod ToEnum()
        {
            return (OsuGameMod)intmod;
        }
        public static bool operator ==(OsuGameModA o1, OsuGameModA o2)
        {
            return (o1.mod == o2.mod);
        }
        public static bool operator !=(OsuGameModA o1, OsuGameModA o2)
        {
            return (o1.mod != o2.mod);
        }
        public static OsuGameModA
            Easy = new OsuGameModA("EZ"),
            HalfTime = new OsuGameModA("HT"),
            NoFail = new OsuGameModA("NF"),
            HardRock = new OsuGameModA("HR"),
            SuddenDeath = new OsuGameModA("SD"),
            Perfect = new OsuGameModA("PF"),
            DoubleTime = new OsuGameModA("DT"),
            NightCore = new OsuGameModA("NC"),
            Hidden = new OsuGameModA("HD"),
            FadeIn = new OsuGameModA("FI"),
            Flashlight = new OsuGameModA("FL"),
            Key1 = new OsuGameModA("1K"),
            Key2 = new OsuGameModA("2K"),
            Key3 = new OsuGameModA("3K"),
            Key4 = new OsuGameModA("4K"),
            Key5 = new OsuGameModA("5K"),
            Key6 = new OsuGameModA("6K"),
            Key7 = new OsuGameModA("7K"),
            Key8 = new OsuGameModA("8K"),
            Key9 = new OsuGameModA("9K"),
            Relax = new OsuGameModA("RL"),
            AutoPilot = new OsuGameModA("AP"),
            SpunOut = new OsuGameModA("SO"),
            KeyCoop = new OsuGameModA("Co-op"),
            Random = new OsuGameModA("RD"),
            AutoPlay = new OsuGameModA("AP"),
            Cinema = new OsuGameModA("CN"),
            ScoreV2 = new OsuGameModA("V2"),
            Unknown = new OsuGameModA("Unknown");
        public override string ToString()
        {
            if (mod is null)
            {
                return "???";
            }
            return mod;
        }
        public static bool operator ==(OsuGameModA g, OsuGameMod c)
        {
            return g.ToEnum() == c;
        }
        public static bool operator !=(OsuGameModA g, OsuGameMod c)
        {
            return g.ToEnum() == c;
        }
        public static bool operator ==(OsuGameMod g, OsuGameModA c)
        {
            return g == c.ToEnum();
        }
        public static bool operator !=(OsuGameMod g, OsuGameModA c)
        {
            return g != c.ToEnum();
        }

    }
}