﻿namespace osuTools
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    namespace Replay
    {
        public class FileInfoHasNoValue : osuToolsException.osuToolsExceptionBase { public FileInfoHasNoValue(string m) : base(m) { } }
        public class LifeBarGraphCollection
        {
            List<LifeBarGraph> gr = new List<LifeBarGraph>();
            public IReadOnlyList<LifeBarGraph> Data { get => gr; }
            public LifeBarGraphCollection(string s)
            {
                GetData(s);
            }
            public LifeBarGraphCollection()
            {
            }
            void GetData(string str)
            {
                string[] pair = str.Split('|');
                foreach (var value in pair)
                {
                    gr.Add(new LifeBarGraph(value));
                }
            }

        }
        public class LifeBarGraph
        {
            string orgstr;
            double hp = -1;
            int offset = -1;
            public LifeBarGraph() { }
            public LifeBarGraph(string pair)
            {
                orgstr = pair;
                string[] data = orgstr.Split(',');
                if (data.Length < 2) return;
                string HP = data[0];
                string Offset = data[1];
                double.TryParse(HP, out hp);
                int.TryParse(Offset, out offset);
            }
        }
        public class AdditionalRepalyData
        {
            LifeBarGraphCollection l;
            public IReadOnlyList<LifeBarGraph> LifeBarGraphData { get => l.Data; }
            byte[] LZMAstream;
            public byte[] LZMAStream { get => LZMAstream; }
            int len;
            int Length { get => len; }
            public AdditionalRepalyData(byte[] data, int len, string lifebargraphstr)
            {
                LZMAstream = data;
                this.len = len;
                l = new LifeBarGraphCollection(lifebargraphstr);
            }
        }
        public partial class OsrData
        {
            short C300g, C300, C200, C100, C50, Cmiss, maxco;
            int sco, ver;
            List<OsuGameMod> mods = new List<OsuGameMod>();
            public IReadOnlyList<OsuGameMod> Mods { get => mods.AsReadOnly(); }
            double acc;
            string accstr;
            byte mode, per, flag;
            bool perb;
            string md5, beatmapmd5, playern;
            OsuGameMode modestr;
            bool infonovalue;
            BinaryReader r;
            FileInfo Info;
            DateTime dt;
            AdditionalRepalyData adata;
            public AdditionalRepalyData AdditionalData { get => adata; }
            public DateTime PlayTime { get => dt; }
            string d;
            public FileInfo ReplayFile
            {
                get
                {
                    if (infonovalue)
                        throw new FileInfoHasNoValue("当前的构造函数没有为FileInfo赋值");
                    else
                        return Info;

                }
            }
            public OsrData(string Dir)
            {

                {
                    r = new BinaryReader(File.OpenRead(Dir));
                }
                Info = new FileInfo(Dir);
                Read();
            }
            public OsrData(BinaryReader b, string Dir)
            {
                if (b is null)
                {
                    throw new NullReferenceException();
                }
                else
                {
                    r = b;
                }
                Info = new FileInfo(Dir);
                Read();
            }
            public OsrData(BinaryReader b)
            {
                if (b is null)
                {
                    throw new NullReferenceException();
                }
                else
                {
                    r = b;
                }
                Info = null;
                infonovalue = true;
                Read();
            }

            void Read()
            {
                string lfbar = "";
                mode = r.ReadByte();
                modestr = (OsuGameMode)(mode);
                ver = r.ReadInt32();
                flag = r.ReadByte();
                beatmapmd5 = r.ReadString();
                flag = r.ReadByte();
                playern = r.ReadString();
                flag = r.ReadByte();
                md5 = r.ReadString();
                C300 = r.ReadInt16();
                C100 = r.ReadInt16();
                C50 = r.ReadInt16();
                C300g = r.ReadInt16();
                C200 = r.ReadInt16();
                Cmiss = r.ReadInt16();
                acc = AccCalculater(new OsuGameModeA(mode));
                accstr = acc.ToString("p");
                sco = r.ReadInt32();
                maxco = r.ReadInt16();
                per = r.ReadByte();
                if (per == 1)
                {
                    perb = true;
                }
                else
                {
                    perb = false;
                }
                mods = Tools.OsuGameModTools.Parse(r.ReadInt32());
                if (r.ReadByte() == 0x0b)
                    lfbar = r.ReadString();
                dt = new DateTime(r.ReadInt64());
                var datalen = r.ReadInt32();
                byte[] data = r.ReadBytes(datalen);
                adata = new AdditionalRepalyData(data, datalen, lfbar);
                r.ReadDouble();
            }
            double AccCalculater(OsuGameModeA mode)
            {
                double a300 = 1, a200 = 2.0 / 3, a100 = 1.0 / 3, a50 = 1.0 / 6, a150 = 1.0 / 2;
                int ManiaAllHit = C300g + C300 + C200 + C100 + C50 + cMiss;
                int OsuAllHit = C300 + C100 + C50 + Cmiss;
                int CtbAllHit = C50 + C100 + C300 + Cmiss + C200;
                int TaikoAllHit = C300 + C100 + Cmiss;
                double ma300c = c300 + c300g,
                       a300c = c300,
                       a200c = c200 * a200,
                       a100c = c100 * a100,
                       a50c = c50 * a50,
                       a150c = c100 * a150;
                double OsuValue = a300c + a100c + a50c,
                       TaikoValue = a300c + a100c + a150c,
                       CtbValue = a300c + a100c + a50c,
                       ManiaValue = ma300c + a200c + a100c + a50c,
                       InvalidValue = -1;
                if (Mode == OsuGameModeA.Osu)
                {
                    return OsuValue / OsuAllHit;
                }
                if (Mode == OsuGameModeA.Catch)
                {
                    return CtbValue / CtbAllHit;
                }
                if (Mode == OsuGameModeA.Taiko)
                {
                    return TaikoValue / TaikoAllHit;
                }
                if (Mode == OsuGameModeA.Mania)
                {

                    return ManiaValue / ManiaAllHit;
                }
                if (Mode == OsuGameModeA.Unknown)
                {
                    return InvalidValue;
                }
                return InvalidValue;
            }

        }
    }
}