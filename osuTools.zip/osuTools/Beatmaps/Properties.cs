﻿namespace osuTools
{
    namespace Beatmaps
    {
        public partial class Beatmap
        {
            /// <summary>
            /// 谱面对应音频文件的全路径
            /// </summary>
            public string FullAudioFileName { get => fuau; }
            /// <summary>
            /// 谱面对应图片文件的全路径
            /// </summary>
            public string FullBackgroundFileName { get => fubgf; }
            /// <summary>
            /// 谱面对应的视频文件的全路径
            /// </summary>
            public string FullVideoFileName { get { if (havevideo == true) return fuvi; else return null; } }
            /// <summary>
            /// 谱面对应的音频文件名
            /// </summary>
            public string AudioFileName { get => au; }
            /// <summary>
            /// 谱面对应的视频文件名
            /// </summary>
            public string VideoFileName { get { if (havevideo) return vi; else return null; } }
            /// <summary>
            /// 存储谱面的文件夹的全路径
            /// </summary>
            public string BeatmapFolder { get => fullfn.Replace(FileName, ""); }
            /// <summary>
            /// 谱面的MD5
            /// </summary>
            public MD5String MD5 { get => md; }
            public string Source { get => sou; }
            public string Tags { get => tag; }
            public string Maker { get => mak; }
            public string Title { get => t; }
            public string UnicodeTitle { get => ut; }
            public string Artist { get => a; }
            public string UnicodeArtist { get => ua; }
            public string Creator { get => c; }
            public string Difficulty { get => dif; }
            public string Version { get => ver; }
            public string FileName { get => fn; }
            public string FullFileName { get => fullfn; }
            public string DownloadLink { get => dlnk; }
            public string BackgroundFileName { get => bgf; }
            public int BeatmapID { get => id; }
            public double OD { get => od; }
            public double HP { get => hp; }
            public double AR { get => ar; }
            public double CS { get => cs; }
            public double Stars { get => stars; }
        }

    }
}