﻿namespace osuTools
{
    namespace Beatmaps
    {

        using System;
        using System.Collections.Generic;
        using System.Runtime.Serialization;
        using System.Security.Cryptography;
        using System.Text;
        /// <summary>
        /// osu!中打击物件的类型
        /// </summary>
        public enum HitObjectType { HitCircle = 0, Slider = 1, NewCombo = 2, Spinner = 3, OsuManiaHold = 7 }
        /// <summary>
        /// 表示一个osu!的打击物件
        /// </summary>
        public class HitObject 
        {
            /// <summary>
            /// 游戏模式
            /// </summary>
            public OsuGameMode BeatmapMode { get; private set; }
            /// <summary>
            /// 对于Mania而言的X
            /// </summary>
            public int ManiaX { get; private set; }
            /// <summary>
            /// 没有缩放的x坐标
            /// </summary>
            public int x { get; private set; }
            /// <summary>
            /// 没有缩放的y坐标
            /// </summary>
            public int y { get; private set; }
            /// <summary>
            /// 与开始间隔的时间，以毫秒为单位
            /// </summary>
            public int Offset { get; private set; }
            int edtm = 0;
            /// <summary>
            /// 如果类型是HitObjectType.OsuManiaHold，则计算长条的结束时间。
            /// </summary>
            public int EndTime { get { if (!h.Contains(HitObjectType.OsuManiaHold)) return 0; else return edtm; } private set { edtm = value; } }
            List<HitObjectType> h = new List<HitObjectType>();
            public IReadOnlyList<HitObjectType> HitObjectTypes { get; private set; }
            List<HitObjectType> bitprocessor(int bit)
            {
                List<HitObjectType> lst = new List<HitObjectType>();
                int cur = bit;
                while (cur > 0)
                {
                    double log2 = Math.Log(cur, 2);
                    int log2int = (int)Math.Truncate(log2);
                    int value = (int)Math.Pow(2, log2int);
                    lst.Add((HitObjectType)log2int);
                    cur -= value;
                }
                h = lst;
                return lst;
            }
            /// <summary>
            /// 构造一个HitObject对象。
            /// </summary>
            /// <param name="mode">如果模式不为Mania，column请填0。</param>
            /// <param name="line">HitObject中一行数据</param>
            /// <param name="column">Mania模式才需要填，为谱面的key数</param>
            public HitObject(OsuGameMode mode, string line, int column)
            {
                BeatmapMode = mode;
                string[] args = line.Split(',');
                x = int.Parse(args[0]);
                y = int.Parse(args[1]);
                Offset = int.Parse(args[2]);
                HitObjectTypes = bitprocessor(int.Parse(args[3]));
                foreach (var type in HitObjectTypes)
                {
                    if (mode==OsuGameMode.Mania)
                    {
                        ManiaX = (int)Math.Floor((double)x * column / 512);
                        edtm = line[5];
                    }
                }
            }
            public override string ToString()
            {
                string tpstr = "";
                foreach(var c in h)
                {
                    if (c==(HitObjectType.HitCircle) || c==(HitObjectType.Slider) || c==(HitObjectType.Spinner)||c==HitObjectType.OsuManiaHold)
                    {
                        tpstr += c+",";
                    }
                }
                var tmp=tpstr.Trim(',');
                return $"x:{x} y:{y} Offset:{Offset} Type:{tmp}";
            }
        }
        /// <summary>
        /// 表示一个休息时间。
        /// </summary>
        public class BreakTime
        {
            public long Start { get; internal set; }
            public long End { get; internal set; }
            /// <summary>
            /// 休息时间的间隔。
            /// </summary>
            public TimeSpan Period { get { return TimeSpan.FromMilliseconds(End - Start); } }
            public override string ToString()
            {
                return $"{Start} to {End}";
            }
            public BreakTime(long start, long end)
            {
                Start = start;
                End = end;
            }
            public bool InBreakTime(long offset)
            {
                if (offset > Start && offset < End)
                    return true;
                else return false;
            }
        }
        /// <summary>
        /// 将MD5以字符串的形式表示。
        /// </summary>
        [Serializable]
        public class MD5String : ISerializable
        {
            [System.NonSerialized]
            MD5 md5;
            string md5str="";
            public MD5String(SerializationInfo info, StreamingContext stream)
            {
                md5str = info.GetString("MD5Str");
            }
            public void GetObjectData(SerializationInfo info, StreamingContext stream)
            {
                if (md5 == null) throw new System.NullReferenceException("无法序列化未初始化的类型。");
                if (md5str == null)
                    ConvertToString();

                if (!string.IsNullOrEmpty(md5str))
                {
                    info.SetType(GetType());
                    info.AssemblyName = "osuTools";
                    info.FullTypeName = "osuTools.Beatmaps.MD5String";
                    info.AddValue("MD5Str", md5str);
                }
                else
                {
                    throw new System.NullReferenceException("MD5字符串为空");
                }
            }
            /// <summary>
            /// 存储在类中的System.Security.Cryptography.MD5对象
            /// </summary>
            public MD5 CurrentMD5 { get => md5; }
            /// <summary>
            /// 使用MD5字符串构建新的MD5String对象。CurrentMD5将会被设置为null。
            /// </summary>
            /// <param name="md5"></param>
            public MD5String(string md5)
            {
                this.md5 = null;               
                md5str = md5;               
            }
            /// <summary>
            /// 使用System.Security.Cryptography.MD5来构建一个新的MD5String。
            /// </summary>
            /// <param name="md5"></param>
            public MD5String(MD5 md5)
            {
                this.md5 = md5;
            }
            /// <summary>
            /// 将System.Security.Cryptography.MD5中的Hash转化为字符串。
            /// </summary>
            /// <param name="md5">要转化的MD5对象</param>
            /// <returns>转换后的MD5字符串</returns>
            public static string GetString(MD5 md5)
            {
                if (md5.Hash.Length == 0) throw new System.NullReferenceException();
                StringBuilder stringBuilder = new StringBuilder();
                foreach (byte b in md5.Hash)
                {
                    stringBuilder.Append(b.ToString("x2"));
                }
                return stringBuilder.ToString();
            }
            /// <summary>
            /// 将一个byte数组转换成MD5字符串。
            /// </summary>
            /// <param name="md5">要转换的字符数组</param>
            /// <returns>转换后的MD5字符串</returns>
            public static string GetString(byte[] md5)
            {
               
                StringBuilder stringBuilder = new StringBuilder();
                foreach (byte b in md5)
                {
                    stringBuilder.Append(b.ToString("x2"));
                }
                return stringBuilder.ToString();
            }
            public MD5String()
            {
                md5str = "";
                md5 = new MD5CryptoServiceProvider();
            }
            /// <summary>
            /// 返回其中存储的转化为字符串的MD5
            /// </summary>
            /// <returns></returns>
            public override string ToString()
            {
                ConvertToString();
                return md5str;
            }
            void ConvertToString()
            {
                if (string.IsNullOrEmpty(md5str))
                {
                    try
                    {
                        if (md5 is null || md5.Hash is null) throw new NullReferenceException();

                    }
                    catch (NullReferenceException)
                    {
                        md5str = "";
                        return;
                    }                  
                   StringBuilder stringBuilder = new StringBuilder();
                   foreach (byte b in md5.Hash)
                   {
                       stringBuilder.Append(b.ToString("x2"));
                   }
                   md5str = stringBuilder.ToString();
                    
                }
                else
                {
                }
            }
            public static bool operator ==(MD5String obja, MD5String objb)
            {
                if (obja is null) throw new ArgumentException("要比较的的MD5为空。");
                if (objb is null) throw new ArgumentException("被比较的的MD5为空。");
                if (string.Compare(obja.ToString(), objb.ToString(), true) != 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            public static bool operator !=(MD5String obja, MD5String objb)
            {
                if (obja is null) throw new ArgumentException("要比较的的MD5为空。");
                if (objb is null) throw new ArgumentException("被比较的的MD5为空。");
                if (string.Compare(obja.ToString(), objb.ToString(), true) == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            public static bool operator ==(MD5String obja, string objb)
            {
                if (obja is null) throw new ArgumentException("要比较的的MD5为空。");
                if (string.Compare(obja.ToString(), objb.ToString(), true) != 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            public static bool operator !=(MD5String obja, string objb)
            {
                if (obja is null) throw new ArgumentException("要比较的的MD5为空。");
                if (string.Compare(obja.ToString(), objb.ToString(), true) == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }

        }
        static class ExtraMethod
        {
            public static MD5String GetMD5String(this MD5 md5)
            {
                return new MD5String(md5);
            }
        }
        enum DataBlock { General, Metadata, Editor, Diffculty, Event, TimePoints, HitObjects, Background, BreakTime, Fail, Pass, Foreground, SoundSample, None }
        /// <summary>
        /// 谱面类，其中包含谱面的信息。
        /// </summary>
        [System.Serializable]
        public partial class Beatmap
        {
            OsuGameMode mode;
            public OsuGameMode Mode { get => mode; }
            string t = "", ut = "", a = "", ua = "", c = "", dif = "", ver = "", fn = "", fullfn = "", dlnk = "", bgf = "", au = "", sou = "", tag = "", mak = "", fuau = "", vi = "", fuvi = "", fubgf = "";
            MD5String md = new MD5String();
            bool havevideo = false;
            double od = 0, cs = 0, hp = 0, ar = 0, stars = 0;
            int m = 0;
            int id = -2048, setid = -2048, mco = 0;
            public int BeatmapSetID { get { if (setid == -2048) throw new NotSupportedException("暂不支持从谱面文件中获取BeatmapSetID"); else return setid; } }
            bool ModeHasSet = false;
            [System.NonSerialized]
            StringBuilder b = new StringBuilder();
            bool FileDataAvalable = false, FileStreamAvalable = false;
            System.IO.FileInfo info;
            [System.NonSerialized]
            MD5CryptoServiceProvider md5calc = new MD5CryptoServiceProvider();
            System.Collections.Generic.List<BreakTime> breaktimes = new System.Collections.Generic.List<BreakTime>();
            public System.Collections.Generic.IReadOnlyList<BreakTime> BreakTimes { get => breaktimes.AsReadOnly(); }
            double bpm;
            public System.IO.FileInfo BeatmapFile { get { if (FileStreamAvalable) { return info; } else throw new System.NotSupportedException(); } }
            //OsuRTDataProvider.BeatmapInfo.Beatmap bmap;
            //public OsuRTDataProvider.BeatmapInfo.Beatmap ToOsuRTDataProviderBeatmap { get => bmap; }
            public Beatmap(Online.OnlineBeatmap olbeatmap)
            {
                t = olbeatmap.Title;
                ut = t;
                a = olbeatmap.Artist;
                ua = a;
                c = olbeatmap.Creator;
                dif = olbeatmap.Version;
                ver = dif;
                fn = "";
                fullfn = "";
                dlnk = "";
                sou = olbeatmap.Source;
                tag = olbeatmap.Tags;
                mak = "";
                md = new MD5String(olbeatmap.MD5);
                fuau = "";
            }
            internal void SetBeatmapID(int beatmap_id)
            {
                id = beatmap_id;
            }
            internal void SetBeatmapSetID(int beatmapset_id)
            {
                setid = beatmapset_id;
            }
            /// <summary>
            /// 在指定的文件夹搜索该谱面的录像。
            /// </summary>
            /// <param name="replyfolder">要搜索的文件夹</param>
            /// <returns>返回一个存储录像信息的类的数组</returns>
            public Replay.ReplayCollection GetReplaysForBeatmap(string replyfolder = "")
            {
                OsuInfo info = new OsuInfo();
                Replay.ReplayCollection r = new Replay.ReplayCollection();
                if (replyfolder == "")
                    replyfolder = info.OsuDirectory + "\\Replays";
                var replays = Replay.ReplayCollection.GetAllReplays(replyfolder);
                foreach (var replay in replays)
                {
                    if (replay.BeatmapMD5 == MD5.ToString())
                        r.Add(replay);
                }
                return r;
            }
            /// <summary>
            /// 使用osu!api在线查询谱面信息
            /// </summary>
            /// <returns></returns>
            public Online.OnlineBeatmap GetOnlineBeatmap()
            {
                string osuApiKey = "fa2748650422c84d59e0e1d5021340b6c418f62f";
                Online.OsuApiQuery q = new Online.OsuApiQuery() { QueryType = Online.OsuApiQueryType.Beatmaps, ApiKey = osuApiKey, BeatmapID = BeatmapID };
                return new Online.OnlineBeatmap((Newtonsoft.Json.Linq.JObject)q.Query().First);
            }
            /// <summary>
            /// 将该谱面转换成OsuBeatmap
            /// </summary>
            /// <returns></returns>
            public OsuDB.OsuBeatmap FindInOsuDB()
            {
                OsuInfo info = new OsuInfo();
                OsuDB.BaseDB baseDB = new OsuDB.BaseDB();
                return baseDB.Beatmaps.FindByMD5(MD5.ToString());
            }
            /// <summary>
            /// 使用OsuBeatmap初始化Beatmap对象
            /// </summary>
            /// <param name="beatmap"></param>
            /// <param name="getStars"></param>
            public Beatmap(OsuDB.OsuBeatmap beatmap, bool getStars = true)
            {
                OsuInfo info = new OsuInfo();
                t = beatmap.Title;
                ut = beatmap.TitleUnicode;
                a = beatmap.Artist;
                ua = beatmap.ArtistUnicode;
                c = beatmap.Creator;
                dif = beatmap.Difficulty;
                ver = dif;
                fn = beatmap.FileName;
                fullfn = info.BeatmapDirectory + "\\" + beatmap.FolderName + "\\" + beatmap.FileName;
                dlnk = $"http://osu.ppy.sh/b/{beatmap.BeatmapID}";
                sou = beatmap.Source;
                tag = beatmap.Tags;
                mak = "";
                md = new MD5String(beatmap.MD5);
                fuau = info.BeatmapDirectory + "\\" + beatmap.FolderName + "\\" + beatmap.AudioFileName;
                fuvi = "";
                od = beatmap.OD;
                hp = beatmap.HPDrain;
                ar = beatmap.AR;
                cs = beatmap.CS;
                setid = beatmap.BeatmapSetID;
                au = beatmap.AudioFileName;
                mode = beatmap.Mode;
                if (getStars)
                    double.TryParse(beatmap.Stars.ToString(), out stars);
                else stars = 0;
                if (fullfn == "" || !System.IO.File.Exists(fullfn)) return;
                var alllines = System.IO.File.ReadAllLines(FullFileName);
                foreach (string line in alllines)
                {
                    var temparr = line.Split(':');
                    if (temparr[0].StartsWith("0,0,\""))
                    {
                        if (!string.IsNullOrEmpty(bgf))
                            bgf = temparr[0].Split(',')[2].Replace("\"", "").Trim();
                    }
                    if (temparr[0].StartsWith("Video,"))
                    {
                        if (!string.IsNullOrEmpty(vi))
                        {
                            vi = temparr[0].Split(',')[2].Replace("\"", "").Trim();
                            havevideo = true;
                        }
                        else
                        {
                            havevideo = false;
                        }
                    }
                    fuvi = FullFileName.Replace(FileName, vi);
                    if (line.Contains("TimingPoints"))
                    {
                        break;
                    }
                }
                SetBeatmapID(beatmap.BeatmapID);

            }
            public static bool operator ==(Beatmap a, Beatmap b)
            {
                try
                {
                    return a.MD5 == b.MD5;
                }
                catch (NullReferenceException)
                {
                    return false;
                }

            }
            public static bool operator !=(Beatmap a, Beatmap b)
            {
                try
                {
                    return a.MD5 != b.MD5;
                }
                catch (NullReferenceException) 
                { return false; 
                }
                
            }
            /// <summary>
            /// 获取谱面的BreakTimes
            /// </summary>
            /// <returns>返回一个BreatTime数组</returns>
            public BreakTime[] GetBreakTimes()
            {
                DataBlock block = DataBlock.None;
                string[] map = System.IO.File.ReadAllLines(FullFileName);
                foreach (string str in map)
                {
                    if (str.Contains("Storyboard") && str.StartsWith("//"))
                    {
                        block = DataBlock.Background;
                    }
                    if (str.Contains("Break Periods") && str.StartsWith("//"))
                    {
                        block = DataBlock.BreakTime;
                    }
                    if (block == DataBlock.BreakTime)
                    {

                        string[] breakstr = str.Split(',');
                        if (breakstr.Length == 3)
                        {
                            if (int.Parse(breakstr[0]) == 2)
                                breaktimes.Add(new BreakTime(long.Parse(breakstr[1]), long.Parse(breakstr[2])));
                        }
                    }
                    if (str.Contains("HitObjects"))
                    {
                        block = DataBlock.HitObjects;
                        System.Diagnostics.Debug.WriteLine(block);
                        break;
                    }
                }
                return breaktimes.ToArray();
            }
            /// <summary>
            /// 获取谱面的HitObjects
            /// </summary>
            /// <returns>返回一个HitObjects数组</returns>
           public HitObject[] GetHitObjects()
            {
                DataBlock block = DataBlock.None;
                List<HitObject> objects = new List<HitObject>();
                string[] map = System.IO.File.ReadAllLines(FullFileName);
                foreach(var str in map)
                {                  
                    if (str.Contains("[HitObjects]"))
                    {
                        block = DataBlock.HitObjects;
                        continue;
                    }
                    if(block==DataBlock.HitObjects)
                    {
                        string[] comasp = str.Split(',');
                        if (comasp.Length > 4)
                        {
                            objects.Add(new HitObject(Mode, str, (int)CS));
                        }
                    }                    
                }                
                return objects.ToArray();
            }
            /// <summary>
            /// 通过OsuRTDataProvider.BeatmapInfo.Beatmap构造Beatmap对象。
            /// </summary>
            /// <param name="x"></param>
            public Beatmap(OsuRTDataProvider.BeatmapInfo.Beatmap x)
            {
                //bmap = x;

                RtppdInfo rt = new RtppdInfo();
                FileDataAvalable = true;
                t = x.Title;
                id = x.BeatmapID;
                ut = x.TitleUnicode;
                a = x.Artist;
                ua = x.ArtistUnicode;
                c = x.Creator;
                dif = x.Difficulty;
                ver = x.Version;
                fn = x.Filename;
                fullfn = x.FilenameFull;
                dlnk = x.DownloadLink;
                bgf = x.BackgroundFilename;
                id = x.BeatmapID;
                vi = x.VideoFilename;
                sou = "";
                tag = "";
                mak = "";
                au = x.AudioFilename;
                md5calc.ComputeHash(System.IO.File.ReadAllBytes(x.FilenameFull));
                md = md5calc.GetMD5String();
                stars = rt.BeatmapTuple.Stars;
                b = new StringBuilder(FullFileName);
                b.Replace(FileName, VideoFileName);
                fuvi = b.ToString();
                b = new StringBuilder(FullFileName);
                b.Replace(FileName, BackgroundFileName);
                fubgf = b.ToString();
                var alllines = System.IO.File.ReadAllLines(x.FilenameFull);
                foreach (string line in alllines)
                {
                    var temparr = line.Split(':');
                    if (temparr[0].Contains("CircleSize"))
                    {
                        double.TryParse(temparr[1].Trim(), out cs);
                    }
                    if (temparr[0].Contains("OverallDifficulty"))
                    {
                        double.TryParse(temparr[1].Trim(), out od);
                    }
                    if (temparr[0].Contains("ApproachRate"))
                    {
                        double.TryParse(temparr[1].Trim(), out ar);
                    }
                    if (temparr[0].Contains("HPDrainRate"))
                    {
                        double.TryParse(temparr[1].Trim(), out hp);
                    }
                    if (temparr[0].Contains("Maker:"))
                    {
                        mak = line.Replace("Maker:", "").Trim();
                    }
                    if (temparr[0].Contains("Source:"))
                    {
                        sou = line.Replace("Source:", "").Trim();
                    }
                    if (temparr[0].Contains("Tags:"))
                    {
                        tag = line.Replace("Tags:", "").Trim();
                    }
                    if (temparr[0].StartsWith("0,0,\""))
                    {
                        if (!string.IsNullOrEmpty(bgf))
                            bgf = temparr[0].Split(',')[2].Replace("\"", "").Trim();
                    }
                    if (temparr[0].StartsWith("Video,"))
                    {
                        if (!string.IsNullOrEmpty(vi))
                        {
                            vi = temparr[0].Split(',')[2].Replace("\"", "").Trim();
                            havevideo = true;
                        }
                        else
                        {
                            havevideo = false;
                        }
                    }
                    fuau = x.FilenameFull.Replace(x.Filename, x.AudioFilename);
                    fuvi = x.FilenameFull.Replace(x.Filename, x.VideoFilename);
                    if (line.Contains("TimingPoints"))
                    {
                        break;
                    }
                }
            }
            public Beatmap()
            {
                fuau = "";
                au = "";
                t = "";
                ut = "";
                a = "";
                ua = "";
                c = "";
                dif = "";
                ver = "";
                fn = "";
                fullfn = "";
                dlnk = "";
                bgf = "";
                mak = "";
                sou = "";
                tag = "";
                md = new MD5String("");
                id = 0;
            }
            internal bool notv = false;
            public override string ToString()
            {
                return $"{Artist} - {Title} [{Version}]";
            }
            /// <summary>
            /// 通过osu文件路径来构造一个Beatmap
            /// </summary>
            /// <param name="s">osu文件路径</param>
            public Beatmap(string s)
            {
                FileDataAvalable = true;
                FileStreamAvalable = true;

                info = null;

                if (System.IO.File.Exists(s))
                {
                    info = new System.IO.FileInfo(s);
                }
                else
                {
                    throw new System.IO.FileNotFoundException("无法找到指定的谱面。");
                }
                int i = 0;
                fn = info.Name;
                fullfn = info.FullName;
                string[] map = System.IO.File.ReadAllLines(s);
                try
                {
                    if (map.Length == 0)
                        throw new osuToolsException.InvalidBeatmapFile($"文件{s}为空。");
                    if (!map[0].Contains("osu file format"))
                        throw new osuToolsException.InvalidBeatmapFile($"文件{s}不是谱面文件。");
                }
                catch
                {
                    notv = true;
                }
                DataBlock block = DataBlock.None;

                foreach (string str in map)
                {
                    i++;
                    string[] temparr = str.Split(':');
                    if (temparr[0].Contains("AudioFile"))
                    {
                        au = temparr[1].Trim();
                        fuau = info.DirectoryName + "\\" + AudioFileName;
                    }
                    if (temparr[0].Contains("Title") && temparr[0].Length <= "Titleuni".Length)
                    {
                        t = temparr[1].Trim();
                    }

                    if (temparr[0].Contains("TitleUnicode"))
                    {
                        ut = str.Replace("TitleUnicode:","").Trim();
                    }
                    if (temparr[0].Contains("Artist") && temparr[0].Length <= "Artistuni".Length)
                    {
                        a = str.Replace("Artist:", "").Trim();
                    }
                    if (temparr[0].Contains("ArtistUnicode"))
                    {
                        ua = str.Replace("ArtistUnicode:", "").Trim();
                    }
                    if (temparr[0].Contains("Creator"))
                    {
                        c = str.Replace("Creator:", "").Trim();
                    }
                    if (temparr[0].Contains("Version"))
                    {
                        ver = str.Replace("Version:", "").Trim();
                        dif = ver;
                    }
                    if (temparr[0].Contains("Maker"))
                    {
                        mak = str.Replace("Maker:", "").Trim();

                    }
                    if (temparr[0].Contains("Source"))
                    {
                        sou = str.Replace("Source:", "").Trim();

                    }
                    if (temparr[0].Contains("Tags"))
                    {
                        tag = str.Replace("Tags:", "").Trim();

                    }
                    if (temparr[0].Contains("BeatmapID"))
                    {
                        int.TryParse(temparr[1].Trim(), out id);
                    }
                    if (temparr[0].Contains("CircleSize"))
                    {
                        double.TryParse(temparr[1].Trim(), out cs);
                    }
                    if (temparr[0].Contains("OverallDifficulty"))
                    {
                        double.TryParse(temparr[1].Trim(), out od);
                    }
                    if (temparr[0].Contains("ApproachRate"))
                    {
                        double.TryParse(temparr[1].Trim(), out ar);
                    }
                    if (temparr[0].Contains("HPDrainRate"))
                    {
                        double.TryParse(temparr[1].Trim(), out hp);
                    }
                    if (temparr[0].Contains("Mode"))
                    {
                        if (!ModeHasSet)
                        {
                            int.TryParse(temparr[1].Trim(), out m);
                            mode = (OsuGameMode)(m);
                            ModeHasSet = true;
                        }
                    }

                    dlnk = $"http://osu.ppy.sh/b/{BeatmapID}";
                    if (str.StartsWith("0,0,\""))
                    {
                        bgf = str.Split(',')[2].Replace("\"", "").Trim();
                    }
                    if (str.StartsWith("Video,"))
                    {
                        vi = str.Split(',')[2].Replace("\"", "").Trim();
                        havevideo = true;
                    }
                }
                md5calc.ComputeHash(System.IO.File.ReadAllBytes(info.FullName));
                md = md5calc.GetMD5String();
            }
            public void SetHPDrainRate(double Value)
            {
                hp = Value;
            }
            public void SetCircleSize(double Value)
            {
                cs = Value;
            }
            public void SetApproachRate(double Value)
            {
                ar = Value;
            }
            public void SetOverallDifficulty(double Value)
            {
                od = Value;
            }
            public void SetStars(double Value)
            {
                stars = Value;
            }
        }
    }
}