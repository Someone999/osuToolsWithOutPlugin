﻿namespace osuTools
{
    public class RtppdInfo : RealTimePPDisplayer.Displayer.DisplayerBase
    {
       public RtppdInfo()
        {
            Sync.Tools.IO.CurrentIO.Write($"[osuTools]  Initialized Beatmap:Stars{BeatmapTuple.Stars}  RealTimeStars:{BeatmapTuple.RealTimeStars}");
        }
    }
}
