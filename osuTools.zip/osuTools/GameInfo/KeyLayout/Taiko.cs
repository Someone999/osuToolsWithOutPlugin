﻿namespace osuTools.KeyLayouts
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Windows.Forms;
    /// <summary>
    /// Taiko模式的按键
    /// </summary>
    public class TaikoKeyLayout
    {
        string[] lines;
        Dictionary<string, Keys> layout;
        internal List<string> InternalName = new List<string>(new string[] { "keyTaikoInnerLeft", "keyTaikoInnerRight", "keyTaikoOuterLeft", "keyTaikoOuterRight" });
        public Dictionary<string, Keys> KeyLayout { get => layout; }
        Dictionary<string, Keys> keyandint = new Dictionary<string, Keys>();
        void InitKeysDict()
        {
            var values = Enum.GetValues(typeof(Keys));
            var names = Enum.GetNames(typeof(Keys));
            try
            {
                for (int i = 0; i < values.Length; i++)
                {
                    keyandint.Add(names[i], (Keys)values.GetValue(i));
                }
            }
            catch
            {

            }
        }
        void InitKeyLayout()
        {
            layout = new Dictionary<string, Keys>();
            layout.Add("RedLeft", Keys.X);
            layout.Add("RedRight", Keys.C);
            layout.Add("BlueLeft", Keys.Z);
            layout.Add("BlueRight", Keys.V);
        }
        public TaikoKeyLayout(string[] data)
        {
            lines = data;
            InitKeysDict();
            InitKeyLayout();
            Parse();
        }
        public TaikoKeyLayout(string ConfigFile)
        {
            lines = File.ReadAllLines(ConfigFile);
            InitKeysDict();
            InitKeyLayout();
            Parse();
        }
        void Parse()
        {
            foreach (var data in lines)
            {
                if (data.StartsWith("keyTaikoInnerLeft"))
                {
                    layout["RedLeft"] = keyandint.CheckIndexAndGetValue(data.Trim().Split('=')[1].Trim());
                }
                if (data.StartsWith("keyTaikoInnerRight"))
                {
                    layout["RedRight"] = keyandint.CheckIndexAndGetValue(data.Trim().Split('=')[1].Trim());
                }
                if (data.StartsWith("keyTaikoOuterLeft"))
                {
                    layout["BlueLeft"] = keyandint.CheckIndexAndGetValue(data.Trim().Split('=')[1].Trim());
                }
                if (data.StartsWith("keyTaikoOuterRight"))
                {
                    layout["BlueRight"] = keyandint.CheckIndexAndGetValue(data.Trim().Split('=')[1].Trim());
                }
            }
        }
        public override string ToString()
        {
            string tmp = "";
            for (int i = 0; i < layout.Count; i++)
            {
                if (i + 1 != layout.Count)
                {

                    tmp += layout.Values.ToString() + " ";
                }
                else
                {
                    tmp += layout.Values.ToString();
                }

            }
            return tmp;
        }
    }
}