﻿namespace osuTools
{
    using System.Collections.Generic;
    namespace Skins
    {
        /// <summary>
        /// 存储Mania特定的皮肤信息
        /// </summary>
        public class ManiaSkinBasicInfo : ManiaSkinBase
        {
            public int HitPosition { get => hitpos; }
            int hitpos;
            bool bar;
            public bool JudgementLine { get => judge; }
            public bool BarlineHeight { get => bar; }
            bool judge;
            public ManiaSkinBasicInfo(int hitPosion, bool judgementLine, bool barline)
            {
                hitpos = hitPosion;
                judge = judgementLine;
            }
        }
        public class ManiaSkinConfig
        {
            string[] lines;
            public ManiaSkinConfig(string[] data)
            {
                lines = data;
                Parse();
            }
            Dictionary<int, ManiaSkinBasicInfo> skininfo;
            public ManiaSkinBasicInfo Key1 { get => skininfo.CheckIndexAndGetValue(1); }
            public ManiaSkinBasicInfo Key2 { get => skininfo.CheckIndexAndGetValue(2); }
            public ManiaSkinBasicInfo Key3 { get => skininfo.CheckIndexAndGetValue(3); }
            public ManiaSkinBasicInfo Key4 { get => skininfo.CheckIndexAndGetValue(4); }
            public ManiaSkinBasicInfo Key5 { get => skininfo.CheckIndexAndGetValue(5); }
            public ManiaSkinBasicInfo Key6 { get => skininfo.CheckIndexAndGetValue(6); }
            public ManiaSkinBasicInfo Key7 { get => skininfo.CheckIndexAndGetValue(7); }
            public ManiaSkinBasicInfo Key8 { get => skininfo.CheckIndexAndGetValue(8); }
            public ManiaSkinBasicInfo Key9 { get => skininfo.CheckIndexAndGetValue(9); }
            void Parse()
            {
                int hitPos = 0;
                bool judgeLine = false;
                bool barLine = false;
                int k = 0;
                skininfo = new Dictionary<int, ManiaSkinBasicInfo>();
                for (int i = 0; i < lines.Length; i++)
                {

                    if (lines[i].Contains("Keys:"))
                    {
                        //System.Diagnostics.Debug.WriteLine(lines[i]);
                        k = int.Parse(lines[i].Split(':')[1].Trim());
                    }
                    if (lines[i].Contains("JudgementLine"))
                    {
                        int x = int.Parse(lines[i].Split(':')[1].Trim()); ;
                        judgeLine = x.ToBool();
                    }
                    if (lines[i].Contains("HitPosition"))
                    {
                        hitPos = int.Parse(lines[i].Split(':')[1].Trim());
                    }
                    if (lines[i].Contains("BarlineHeight"))
                    {
                        barLine = (int.Parse(lines[i].Split(':')[1].Trim())).ToBool();
                    }

                    skininfo[k] = new ManiaSkinBasicInfo(hitPos, judgeLine, barLine);
                }
            }

        }
    }
}