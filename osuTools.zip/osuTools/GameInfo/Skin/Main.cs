﻿namespace osuTools
{
    namespace Skins
    {
        using System.IO;
        /// <summary>
        /// 存储皮肤的基本信息
        /// </summary>
        public class Skin
        {
            string[] lines;
            ManiaSkinConfig maniaSkin;
            public ManiaSkinConfig ManiaSkin { get => maniaSkin; }
            string skin;
            string SkinDir { get => skin; }
            public Skin(string SkinDir)
            {
                string skinini = SkinDir;
                if (!SkinDir.Contains("skin.ini"))
                    skinini = Path.Combine(SkinDir, "skin.ini");
                if (File.Exists(skinini))
                {
                    lines = File.ReadAllLines(skinini);
                    skin = skinini.Replace("skin.ini", "");
                }
                else
                {
                    throw new FileNotFoundException();
                }

                GetInfo();
            }
            void GetInfo()
            {

                maniaSkin = new ManiaSkinConfig(lines);
                for (int i = 0; i < lines.Length; i++)
                {
                    //System.Diagnostics.Debug.WriteLine(lines[i]);


                    if (lines[i].Contains("Name"))
                    {
                        name = lines[i].Split(':')[1].Trim();
                    }
                    if (lines[i].Contains("Author"))
                    {
                        author = lines[i].Split(':')[1].Trim();
                    }
                }
            }
            public string Name { get => name; }
            string name;
            public string Author { get => author; }
            public string ConfigFileDir { get => Path.Combine(SkinDir, "skin.ini"); }
            string author;
        }
    }
}