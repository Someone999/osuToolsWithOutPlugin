﻿namespace osuTools.OsuDB
{
    interface IOsuDBData
    {

    }
    interface IOsuDB
    {
        void Read();
    }
}