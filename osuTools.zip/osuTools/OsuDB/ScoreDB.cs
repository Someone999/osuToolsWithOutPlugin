﻿using System;
using System.Collections.Generic;
using System.IO;
namespace osuTools.OsuDB
{
    public class ScoreMainfest
    {
        public ScoreMainfest(int ver)
        {
            Version = ver;
        }
        public int Version { get; internal set; }
    }
    /// <summary>
    /// scores.db中存储的成绩
    /// </summary>
    public class ScoreDBData : IOsuDBData
    {
        public ScoreDBData(OsuGameMode mode, int ver, string bmd5, string name, string rmd5, short c300, short c100, short c50, short c300g, short c200, short cmiss, int score, short maxcombo, bool per, int mods, string empty, long playtime, int verify, long scoreid)
        {
            this.mode = mode;
            //System.Windows.Forms.MessageBox.Show(Mode.ToString());
            this.ver = ver;
            bemd5 = bmd5;
            remd5 = rmd5;
            pn = name;
            C300g = c300g;
            C300 = c300;
            C200 = c200;
            C100 = c100;
            C50 = c50;
            CMiss = cmiss;
            sc = score;
            maxc = maxcombo;
            this.per = per;
            this.mods = Tools.OsuGameModTools.Parse(mods);
            pt = playtime;
            pdt = new DateTime(pt);
            if (verify != -1) throw new osuToolsException.FailToParse("验证失败");
            sid = scoreid;
            //System.Windows.Forms.MessageBox.Show(Score.ToString());
        }
        short C300g, C300, C200, C100, C50, CMiss, maxc;
        bool per; long pt, sid; int ver, sc; OsuGameMode mode; string bemd5, remd5, pn;
        DateTime pdt;
        public int GameVersion { get => ver; }
        public OsuGameMode Mode { get => mode; }
        public string BeatmapMD5 { get => bemd5; }
        public string PlayerName { get => pn; }
        public string ReplayMD5 { get => remd5; }
        public short c300g { get => C300g; }
        public short c300 { get => C300; }
        public short c200 { get => C200; }
        public short c100 { get => C100; }
        public short c50 { get => C50; }
        public short cMiss { get => CMiss; }
        public int Score { get => sc; }
        public short MaxCombo { get => maxc; }
        public bool Perfect { get => per; }
        internal List<OsuGameMod> mods = new List<OsuGameMod>();
        public IReadOnlyList<OsuGameMod> Mods { get => mods.AsReadOnly(); }
        public DateTime PlayTime { get => pdt; }
        public long ScoreID { get => sid; }
    }
    /// <summary>
    /// 从scores.db中读取成绩。
    /// </summary>
    public class ScoreDB : IOsuDB
    {
        List<ScoreDBData> Score = new List<ScoreDBData>();
        int beatmapnum = 0;
        public IReadOnlyList<ScoreDBData> Scores => Score.AsReadOnly();
        public ScoreMainfest Mainfest { get; internal set; } = new ScoreMainfest(-1);
        BinaryReader reader;
     
        public ScoreDB()
        {
            OsuInfo info = new OsuInfo();
            string dbfile = info.OsuDirectory + "scores.db";
            var stream = File.OpenRead(dbfile);
            reader = new BinaryReader(stream);
            Mainfest.Version = reader.ReadInt32();
            beatmapnum = reader.ReadInt32();

        }
        bool IsString()
        {
            reader.ReadByte(); return true;

            //else if (reader.ReadByte() == 0x0b) return true;
            // else throw new osuToolsException.FailToParse("无法读取字符串。");
        }
        System.Windows.Forms.DialogResult msgbox(object o)
        {
            return System.Windows.Forms.MessageBox.Show(o.ToString());
        }
        string GetString() { if (IsString()) return reader.ReadString(); else return string.Empty; }
        short GetShort()
        {
            var v = reader.ReadInt16();
            // msgbox(v);
            return v;
        }
        int GetInt32()
        {
            var v = reader.ReadInt32();
            // msgbox(v);
            return v;
        }
        long GetInt64()
        {
            var v = reader.ReadInt64();
            // msgbox(v);
            return v;
        }
        byte GetByte()
        {
            var v = reader.ReadByte();
            //msgbox(v);
            return v;
        }
        bool GetBool()
        {
            var v = reader.ReadBoolean();
            //msgbox(v);
            return v;
        }
        double GetDouble()
        {
            var v = reader.ReadDouble();
            //msgbox(v);
            return v;
        }
        string GetEmptyString()
        {
            byte b = reader.ReadByte();
            if (b == 0x0b)
            {
                return reader.ReadString();
            }
            //System.Windows.Forms.MessageBox.Show(reader.ReadByte().ToString());
            return "";
        }
        public void Read()
        {
            for (int i = 0; i < beatmapnum; i++)
            {
                string curmd5 = "";
                curmd5 = GetString();
                int scorenum = reader.ReadInt32();
                for (int j = 0; j < scorenum; j++)
                {
                    Score.Add(new ScoreDBData((OsuGameMode)GetByte(), GetInt32(),
                                              GetString(), GetString(), GetString(),
                                              GetShort(), GetShort(), GetShort(),
                                              GetShort(), GetShort(), GetShort(),
                                              GetInt32(), GetShort(), GetBool(),
                                              GetInt32(), GetEmptyString(), GetInt64(),
                                              GetInt32(), GetInt32()));
                    GetInt32();
                }
            }
        }
    }
}