﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using osuTools.Beatmaps;
namespace osuTools.OsuDB
{
    public enum OsuBeatmapStatus {Unknown, Unsubmitted,Pending,Ranked=4,Approved,Qualified,Loved }
    public class OsuBeatmapCollection
    {
        public enum BeatmapIDType {BeatmapID,BeatmapSetID }
        List<OsuBeatmap> beatmaps { get; set; } = new List<OsuBeatmap>();
        public IReadOnlyList<OsuBeatmap> Beatmaps { get => beatmaps.AsReadOnly(); }
        public bool Contains(OsuBeatmap b) => beatmaps.Contains(b);
        public int Count { get => beatmaps.Count; }
        internal void Add(OsuBeatmap b) => beatmaps.Add(b);
        public OsuBeatmap this[int x]
        {
            get => beatmaps[x];
        }
        public OsuBeatmapCollection Find(string KeyWord, Beatmaps.BeatmapCollection.BeatmapFindOption option = BeatmapCollection.BeatmapFindOption.Contains)
        {
            OsuBeatmapCollection b = new OsuBeatmapCollection();
            string keyword = KeyWord.ToUpper();
            foreach (var beatmap in Beatmaps)
            {

                string allinfo = beatmap.ToString().ToUpper() + " " + beatmap.Source.ToUpper() + " " + beatmap.Tags.ToUpper() + " " + beatmap.Creator.ToUpper();
                if (option == BeatmapCollection.BeatmapFindOption.Contains)
                {
                    if (keyword.StartsWith("${") && keyword.EndsWith("}"))
                    {
                        string newkeyw = keyword.Trim('$', '}', '{');
                        if (beatmap.Title.ToUpper() == newkeyw || beatmap.TitleUnicode.ToUpper() == newkeyw || beatmap.Artist.ToUpper() == newkeyw || beatmap.ArtistUnicode.ToUpper() == newkeyw ||
                            beatmap.Creator.ToUpper() == newkeyw || beatmap.Tags.ToUpper() == newkeyw || beatmap.Source.ToUpper() == newkeyw ||
                            beatmap.Difficulty.ToUpper() == newkeyw)
                        {
                            if (!b.Contains(beatmap))
                                b.Add(beatmap);
                        }
                    }
                    else
                    if (allinfo.Contains(keyword))
                        b.Add(beatmap);
                }
                if (option == BeatmapCollection.BeatmapFindOption.NotContains)
                {
                    if (keyword.StartsWith("${") && keyword.EndsWith("}"))
                    {
                        string newkeyw = keyword.Trim('$', '}', '{');
                        if (beatmap.Title.ToUpper() != newkeyw && beatmap.TitleUnicode.ToUpper() != newkeyw && beatmap.Artist.ToUpper() != newkeyw && beatmap.ArtistUnicode.ToUpper() != newkeyw &&
                             beatmap.Creator.ToUpper() != newkeyw && beatmap.Tags.ToUpper() != newkeyw && beatmap.Source.ToUpper() != newkeyw &&
                            beatmap.Difficulty.ToUpper() != newkeyw)
                        {
                            if (!b.Contains(beatmap))
                                b.Add(beatmap);
                        }
                    }
                    else
                    if (!allinfo.Contains(keyword))
                        b.Add(beatmap);
                }
            }
            if (b.Count == 0)
            {
                throw new osuTools.osuToolsException.BeatmapNotFound("找不到指定的谱面");
            }
            return b;
        }
        public OsuBeatmap Find(int ID,BeatmapIDType type=BeatmapIDType.BeatmapID)
        {
            if (ID != -1)
                if(type==BeatmapIDType.BeatmapID)
                foreach (var beatmap in Beatmaps)
                {
                    if (beatmap.BeatmapID == ID)
                    {
                        return beatmap;
                    }
                }
            if(type==BeatmapIDType.BeatmapSetID)
                foreach (var beatmap in Beatmaps)
                {
                    if (beatmap.BeatmapSetID == ID)
                    {
                        return beatmap;
                    }
                }
            return null;
        }
        public OsuBeatmap FindByMD5(string md5)
        {
            foreach (var beatmap in Beatmaps)
            {
                if (beatmap.MD5 == md5)
                {
                    return beatmap;
                }
            }
            throw new osuToolsException.BeatmapNotFound($"找不到MD5为{md5}的谱面。");
        }
        public static implicit operator List<OsuBeatmap>(OsuBeatmapCollection c)=>(List<OsuBeatmap>)c.Beatmaps;
        public OsuBeatmapCollection Find(OsuGameMode Mode, BeatmapCollection.BeatmapFindOption option = BeatmapCollection.BeatmapFindOption.Contains)
        {
            OsuBeatmapCollection bc = new OsuBeatmapCollection();
            foreach (var b in beatmaps)
            {
                if (option == BeatmapCollection.BeatmapFindOption.Contains)
                    if (b.Mode == Mode)
                    {
                        if (!bc.Contains(b))
                            bc.Add(b);
                    }
                if (option == BeatmapCollection.BeatmapFindOption.NotContains)
                    if (b.Mode != Mode)
                    {
                        if (!bc.Contains(b))
                            bc.Add(b);
                    }
            }
            return bc;
        }
        public IEnumerator<OsuBeatmap> GetEnumerator() => beatmaps.GetEnumerator();

    }
    /// <summary>
    /// 一个变速点或时间标志。
    /// </summary>
    public class TimePoint
    {
        internal TimePoint(double bpm, double offset, bool inherit)
        {
            BPM = 1/bpm*1000*60;
            Offset = offset;
            Inherit = inherit;
        }

        public double BPM { get; internal set; }
        public double Offset { get; internal set; }
        /// <summary>
        /// 是否为继承时间线(是不是绿线)
        /// </summary>
        public bool Inherit { get; internal set; }
    }
    /// <summary>
    /// 谱面，存储的信息多于Beatmap类
    /// </summary>
    public class OsuBeatmap : IOsuDBData
    {
        public override string ToString()
        {
            return $"{Artist} - {Title} [{Difficulty}]";
        }
        public  Beatmap ToBeatmap()
        {
            return new Beatmap(this);
        }
        public static bool operator ==(OsuBeatmap a, OsuBeatmap b)
        {
            if (b is null) b = new OsuBeatmap();
            try
            {
                return a.MD5 == b.MD5;
            }
            catch (NullReferenceException)
            {
                return false;
            }
        }
        public static bool operator !=(OsuBeatmap a, OsuBeatmap b)
        {
            if (b is null) b = new OsuBeatmap();
            try
            {
                return a.MD5 == b.MD5;
            }
            catch (NullReferenceException)
            {
                return false;
            }
        }
        public OsuBeatmap()
        {
        }
        public double Stars { get; internal set; }
        public string FolderName { get; internal set; }
        public OsuGameMode Mode { get; internal set; } = OsuGameMode.Unknown;
        public string AudioFileName { get; internal set; }
        public string Artist { get; internal set; }
        public string ArtistUnicode { get; internal set; }
        public string Title { get; internal set; }
        public string TitleUnicode { get; internal set; }
        public string Source { get; internal set; }
        public string Tags { get; internal set; }
        public string Creator { get; internal set; }
        public string Difficulty { get; internal set; }
        public string MD5 { get; internal set; }
        public string FileName { get; internal set; }
        public OsuBeatmapStatus BeatmapStatus { get; internal set; }
        public short HitCircle { get; internal set; }
        public short Slider { get; internal set; }
        public short Spinner { get; internal set; }
        internal long ModifucationTime;
        public DateTime LastModificationTime { get; internal set; }
        public TimeSpan DrainTime { get; internal set; }
        public TimeSpan TotalTime { get; internal set; }
        public TimeSpan PreviewPoint { get; internal set; }
        public double AR { get; internal set; }
        public double OD { get; internal set; }
        public double CS { get; internal set; }
        public double HPDrain { get; internal set; }
        internal List<TimePoint> timepoints = new List<TimePoint>();
        public IReadOnlyList<TimePoint> TimePoints { get => timepoints.AsReadOnly(); }
        public int BeatmapID { get; internal set; }
        public int BeatmapSetID { get; internal set; }
        public DifficultyRate ModStarPair { get; internal set; } = new DifficultyRate();
        public int ThreadID { get; internal set; }

    }
    /// <summary>
    /// 包含指定模式的指定Mods与Star的键值对。
    /// </summary>
    public class DifficultyRate
    {
        internal Dictionary<OsuGameMode, Dictionary<int, double>> Difficuties = new Dictionary<OsuGameMode, Dictionary<int, double>>();
        internal void Add(OsuGameMode mode, int modCombine, double stars)
        {
            Difficuties[mode].Add(modCombine, stars);
        }
        public DifficultyRate() { }
        public Dictionary<int, double> this[OsuGameMode mode] { get => Difficuties[mode]; }
        public double GetStars(OsuGameMode mode, int modCombine)
        {
            return Difficuties[mode][modCombine];
        }
        public void SetStar(OsuGameMode mode, int modCombine, double stars)
        {
            Difficuties[mode][modCombine] = stars;
            return;
        }
        public void SetModeDict(OsuGameMode mode, Dictionary<int, double> dict)
        {
            Difficuties[mode] = dict;
        }
    }
}
namespace osuTools.OsuDB
{
    /// <summary>
    /// osu!中的部分基础信息。
    /// </summary>
    public class OsuMainfest
    {
        /// <summary>
        /// 当前登录用户所拥有的权限。
        /// </summary>
        public enum UserPermission { None, Normal, Moderator, Supporter = 4, Friend = 8, peppy = 16, WorldCupstaff = 32 }
        /// <summary>
        /// 当前游戏的版本。
        /// </summary>
        public int Version { get; internal set; }
        /// <summary>
        /// 当前谱面目录下文件夹的数目
        /// </summary>
        public int FolderCount { get; internal set; }
        /// <summary>
        /// 账号是否处于未封禁的状态。
        /// </summary>
        public bool AccountUnlocked { get; internal set; }
        /// <summary>
        /// 账号解封的时间。
        /// </summary>
        public DateTime AccountUnlockTime { get; internal set; }
        /// <summary>
        /// 当前登录的用户的用户名。
        /// </summary>
        public string PlayerName { get; internal set; }
        /// <summary>
        /// 谱面的数目。
        /// </summary>
        public int NumberOfBeatmap { get; internal set; }
        /// <summary>
        /// 当前登录用户所拥有的权限/
        /// </summary>
        public UserPermission Permission { get; internal set; }
    }
    /// <summary>
    /// 通过读取osu!.db获取所有的谱面以及一些游戏相关的信息。
    /// </summary>
    public class BaseDB : IOsuDB
    {

        BinaryReader reader;
        public OsuMainfest Mainfest { get; internal set; }
        public OsuBeatmapCollection Beatmaps { get; internal set; }
        public MD5String GetMD5()
        {
            System.Security.Cryptography.MD5CryptoServiceProvider provider = new System.Security.Cryptography.MD5CryptoServiceProvider();
            var data = File.ReadAllBytes(f);
            provider.ComputeHash(data);
            return new MD5String(provider);
        }

        string f;
        bool readmainfest = false;
       
        public BaseDB()
        {
            OsuInfo info=new OsuInfo();
            string file = info.OsuDirectory + "osu!.db";
            var stream = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            reader = new BinaryReader(stream);

            f = file;
            //Sync.Tools.IO.CurrentIO.Write(or.CurrentMode.ToString());
            Read();
        }
        public void Read()
        {
            Mainfest = new OsuMainfest();
            Beatmaps = new OsuBeatmapCollection();
            if (!readmainfest)
            {
                ReadMainfest();
            }
            GetAllBeatmaps();
        }
        short GetInt16()
        {
            var v = reader.ReadInt16();
            return v;
        }
        int GetInt32()
        {
            var v = reader.ReadInt32();
            return v;
        }
        long GetInt64()
        {
            var v = reader.ReadInt64();
            return v;
        }
        double GetDouble()
        {
            var v = reader.ReadDouble();
            return v;
        }
        float GetSingle()
        {
            var v = reader.ReadSingle();
            return v;
        }
        byte GetByte()
        {
            var v = reader.ReadByte();
            return v;
        }
        bool GetBoolean()
        {
            var v = reader.ReadBoolean();
            return v;
        }
        string GetString()
        {
            if (reader.ReadByte() == 0x0b)
            {
                string v = reader.ReadString();
                return v;
            }
            else return string.Empty;
        }
        void ReadMainfest()
        {
            Mainfest.Version = GetInt32();
            Mainfest.FolderCount = GetInt32();
            Mainfest.AccountUnlocked = GetBoolean();
            Mainfest.AccountUnlockTime = new DateTime(GetInt64());
            Mainfest.PlayerName = GetString();
            Mainfest.NumberOfBeatmap = GetInt32();
            readmainfest = true;
        }
        ORTDP or = null;
        OsuBeatmap ReadBeatmap()
        {
            Dictionary<int, double> osustars = new Dictionary<int, double>();
            Dictionary<int, double> taikostars = new Dictionary<int, double>();
            Dictionary<int, double> ctbstars = new Dictionary<int, double>();
            Dictionary<int, double> maniastars = new Dictionary<int, double>();
            OsuBeatmap Beatmap = new OsuBeatmap();
            Beatmap.Artist = GetString();
            Beatmap.ArtistUnicode = GetString();
            Beatmap.Title = GetString();
            Beatmap.TitleUnicode = GetString();
            Beatmap.Creator = GetString();
            Beatmap.Difficulty = GetString();
            Beatmap.AudioFileName = GetString();
            Beatmap.MD5 = GetString();
            Beatmap.FileName = GetString();
            Beatmap.BeatmapStatus = (OsuBeatmapStatus)GetByte();
            Beatmap.HitCircle = GetInt16();
            Beatmap.Slider = GetInt16();
            Beatmap.Spinner = GetInt16();
            Beatmap.LastModificationTime = new DateTime(GetInt64());
            Beatmap.AR = GetSingle();
            Beatmap.CS = GetSingle();
            Beatmap.HPDrain = GetSingle();
            Beatmap.OD = GetSingle();
            GetDouble().ToString();
            var pac = GetInt32();
            pac.ToString();
            List<int> intlst = new List<int>();
            for (int i = 0; i < pac; i++)
            {
                int intflag = 0; double doubleflag = 0;
                GetByte();
                intflag = GetInt32();
                GetByte();
                doubleflag = GetDouble();
                osustars.Add((intflag), doubleflag);
            }
            pac = GetInt32();
            for (int i = 0; i < pac; i++)
            {
                int intflag = 0; double doubleflag = 0;
                GetByte();
                intflag = GetInt32();
                GetByte();
                doubleflag = GetDouble();
                taikostars.Add((intflag), doubleflag);
            }
            pac = GetInt32();
            pac.ToString();
            for (int i = 0; i < pac; i++)
            {
                int intflag = 0; double doubleflag = 0;
                GetByte();
                intflag = GetInt32();
                GetByte();
                doubleflag = GetDouble();
                ctbstars.Add((intflag), doubleflag);

            }
            pac = GetInt32();

            for (int i = 0; i < pac; i++)
            {
                int intflag = 0; double doubleflag = 0;
                GetByte();
                intflag = GetInt32();
                GetByte();
                doubleflag = GetDouble();
                if (intlst.Contains(intflag)) throw new Exception();
                intlst.Add(intflag);
                maniastars.Add(intflag, doubleflag);
            }
            Beatmap.DrainTime = TimeSpan.FromSeconds(GetInt32());
            Beatmap.TotalTime = TimeSpan.FromMilliseconds(GetInt32());
            Beatmap.PreviewPoint = TimeSpan.FromMilliseconds(GetInt32());
            pac = GetInt32();
            for (int i = 0; i < pac; i++)
            {
                double BPM = GetDouble();
                double Offset = GetDouble();
                bool Inherit = GetBoolean();
                Beatmap.timepoints.Add(new TimePoint(BPM, Offset, Inherit));
            }
            Beatmap.BeatmapID = GetInt32();
            Beatmap.BeatmapSetID = GetInt32();
            Beatmap.ThreadID = GetInt32();
            GetByte();
            GetByte();
            GetByte();
            GetByte();
            GetInt16();
            GetSingle();
            Beatmap.Mode = (OsuGameMode)GetByte();
            Beatmap.ModStarPair.SetModeDict(OsuGameMode.Osu, osustars);
            Beatmap.ModStarPair.SetModeDict(OsuGameMode.Taiko, taikostars);
            Beatmap.ModStarPair.SetModeDict(OsuGameMode.Catch, ctbstars);
            Beatmap.ModStarPair.SetModeDict(OsuGameMode.Mania, maniastars);
            System.Threading.Tasks.Task.Run(() => { try { Beatmap.Stars = Beatmap.ModStarPair[Beatmap.Mode][0]; } catch { Beatmap.Stars = 0; } });
            Beatmap.Source = GetString();
            Beatmap.Tags = GetString();
            GetInt16();
            GetString();
            GetBoolean();
            GetInt64();
            GetBoolean();
            Beatmap.FolderName = GetString();
            GetInt64();
            GetBoolean();
            GetBoolean();
            GetBoolean();
            GetBoolean();
            GetBoolean();
            GetInt32();
            GetByte();
            return Beatmap;

        }
        void GetAllBeatmaps()
        {
            int i = Mainfest.NumberOfBeatmap;
            OsuBeatmapCollection beatmaps = new OsuBeatmapCollection();
            for (int j = 0; j < i; j++)
            {
                var newbeatmap = ReadBeatmap();
                if(newbeatmap.Title!=""&&newbeatmap.Artist!="")
                beatmaps.Add(newbeatmap);
            }
            Beatmaps = beatmaps;
            reader.Close();
        }
    }
}


