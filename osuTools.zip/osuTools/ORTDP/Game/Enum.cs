﻿namespace osuTools
{
    [System.Serializable]
    public enum OsuGameMode { Osu, Taiko, Catch, Mania, Unknown=-1 };
    [System.Serializable]
    public enum OsuGameStatus { Eiditing, Idle, Lobby, MatchSetup, ProcessNotFound, Playing, Rank, SelectSong, Unknown };
    [System.Serializable]
    public enum OsuGameModAs
    {
        Easy,
        HalfTime,
        NoFail,
        HardRock,
        SuddenDeath,
        Perfect,
        DoubleTime,
        NightCore,
        Hidden,
        FadeIn,
        Flashlight,
        Key1,
        Key2,
        Key3,
        Key4,
        Key5,
        Key6,
        Key7,
        Key8,
        Key9,
        Relax,
        AutoPilot,
        SpunOut,
        KeyCoop,
        Random,
        AutoPlay,
        Cinema,
        ScoreV2,
        Unknown,
    }

    public enum OsuGameMod
    {
        None = 0,//None
        NoFail = 1 << 0,//NF
        Easy = 1 << 1,//EZ
        TouchDevice = 1 << 2,//TouchDevice
        Hidden = 1 << 3,//HD
        HardRock = 1 << 4,//HR
        SuddenDeath = 1 << 5,//SD
        DoubleTime = 1 << 6,//DT
        Relax = 1 << 7,//RX
        HalfTime = 1 << 8,//HT
        NightCore = 1 << 9,//NC
        Flashlight = 1 << 10,//FL
        AutoPlay = 1 << 11,//Auto
        SpunOut = 1 << 12,//SP
        AutoPilot = 1 << 13,//AP
        Perfect = 1 << 14,//PF
        Key4 = 1 << 15,//4K
        Key5 = 1 << 16,//5K
        Key6 = 1 << 17,//6K
        Key7 = 1 << 18,//7K
        Key8 = 1 << 19,//8K
        FadeIn = 1 << 20,//FD
        Random = 1 << 21,//RD
        Cinema = 1 << 22,//CN
        Target = 1 << 23,//Target
        Key9 = 1 << 24,//9K
        KeyCoop = 1 << 25,//Co-op
        Key1 = 1 << 26,//1K
        Key3 = 1 << 27,//2K
        Key2 = 1 << 28,//3K
        ScoreV2 = 1 << 29,//V2
        Mirror = 1 << 30,//MR
        KeyMod = Key1 | Key2 | Key3 | Key4 | Key5 | Key6 | Key7 | Key8 | Key9,
        Unknown = -1,
        FreeModAllowed = NoFail | Easy | Hidden | HardRock | SuddenDeath | Flashlight | FadeIn | Relax | AutoPilot | SpunOut | KeyMod,
        ScoreIncreaseMods = Hidden | HardRock | DoubleTime | Flashlight | FadeIn
    };
}
