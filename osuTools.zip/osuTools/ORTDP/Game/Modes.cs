﻿namespace osuTools
{
    [System.Serializable]
    public partial class GMMode
    {
        OsuGameModeA l = OsuGameModeA.unDefined, m = OsuGameModeA.unDefined;
        public OsuGameMode LastMode { get => l.ToEnum(); }
        public OsuGameMode CurrentMode { get => m.ToEnum(); }
        public GMMode(string LastMode, string NowMode,ref OsuDB.OsuBeatmap bp)
        {
            if (LastMode != "")
            {
                l = new OsuGameModeA(LastMode);
            }
            if (NowMode != "")
            {
                m = new OsuGameModeA(NowMode);
            }
        
           
        }
    }
    namespace Tools
    {
        public static class OsuGameModeTools
        {
            public static OsuGameMode Parse(string mode)
            {
                if (string.Compare(mode, "mania", true) == 0) return OsuGameMode.Mania;
                if (string.Compare(mode, "osu", true) == 0) return OsuGameMode.Osu;
                if (string.Compare(mode, "catch", true) == 0 || string.Compare(mode, "Ctb", true) == 0) return OsuGameMode.Catch;
                if (string.Compare(mode, "taiko", true) == 0) return OsuGameMode.Taiko;
                return OsuGameMode.Unknown;
            }
        }
    }
    [System.Serializable]
    class OsuGameModeA
    {

        public string Mode { get => modea; }
        string modea;
        int modei;
        public OsuGameModeA(int mode)
        {
            switch (mode)
            {
                case 0: modea = Osu.ToString(); modei = mode; ; break;
                case 1: modea = Taiko.ToString(); modei = mode; break;
                case 2: modea = Catch.ToString(); modei = mode; break;
                case 3: modea = Mania.ToString(); modei = mode; break;
                default: modea = Unknown.ToString(); modei = 4; break;
            }
        }
        public OsuGameModeA(OsuGameMode mode)
        {
            switch (mode)
            {
                case OsuGameMode.Osu: modea = Osu.ToString(); modei = (int)mode; ; break;
                case OsuGameMode.Taiko: modea = Taiko.ToString(); modei = (int)mode; break;
                case OsuGameMode.Catch: modea = Catch.ToString(); modei = (int)mode; break;
                case OsuGameMode.Mania: modea = Mania.ToString(); modei = (int)mode; break;
                default: modea = Unknown.ToString(); modei = 4; break;
            }
        }
        public static OsuGameModeA Mania = new OsuGameModeA("Mania");
        public static OsuGameModeA Catch = new OsuGameModeA("CatchTheBeat");
        public static OsuGameModeA Osu = new OsuGameModeA("Osu");
        public static OsuGameModeA Taiko = new OsuGameModeA("Taiko");
        public static OsuGameModeA Unknown = new OsuGameModeA("Unknown");
        public static OsuGameModeA unDefined = new OsuGameModeA("Undefined");
        public OsuGameModeA(string c)
        {
            if (c != "Mania" && c != "CatchTheBeat" && c != "Osu" && c != "Taiko")
            {
                if (c == "Mania")
                {
                    modei = 3;
                }
                if (c == "CatchTheBeat")
                {
                    modei = 2;
                }
                if (c == "Taiko")
                {
                    modei = 1;
                }
                if (c == "Osu")
                {
                    modei = 0;
                }
                c = "Unknown";
            }
            modea = c;

        }

        public static bool operator ==(OsuGameModeA g, OsuGameModeA c)
        {
            return g.Mode == c.Mode || g.Mode.Contains(c.Mode);
        }
        public static bool operator !=(OsuGameModeA g, OsuGameModeA c)
        {
            return g.Mode != c.Mode || !g.Mode.Contains(c.Mode);
        }
        public static bool operator ==(OsuGameModeA g, OsuGameMode c)
        {
            if (g.ToEnum() == c)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator !=(OsuGameModeA g, OsuGameMode c)
        {
            if (g.ToEnum() != c)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator ==(OsuGameMode c, OsuGameModeA g)
        {
            if (g.ToEnum() == c)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator !=(OsuGameMode c, OsuGameModeA g)
        {
            if (g.ToEnum() != c)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public override string ToString()
        {
            return Mode;
        }
        public override bool Equals(object obj)
        {
            OsuGameModeA gm = obj as OsuGameModeA;
            if (gm != null && Mode == gm.Mode)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public OsuGameMode ToEnum()
        {
            if (modea == "Mania")
            {
                modei = 3;
            }
            if (modea == "CatchTheBeat")
            {
                modei = 2;
            }
            if (modea == "Taiko")
            {
                modei = 1;
            }
            if (modea == "Osu")
            {
                modei = 0;
            }
            if (modea == "Unknow")
            {
                modei = 4;
            }
            return (OsuGameMode)modei;
        }
    }
}
