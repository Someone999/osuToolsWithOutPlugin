﻿namespace osuTools
{
    [System.Serializable]
    public partial class GMStatus
    {
        OsuGameStatusA l, m;
        public OsuGameStatus LastStatus { get => l.ToEnum(); }
        public OsuGameStatus CurrentStatus { get => m.ToEnum(); }
        public GMStatus(string Last, string Now)
        {
            if (Last == null || Last == "")
            {
                l = new OsuGameStatusA("Unknown");
            }
            else
            {
                l = new OsuGameStatusA(Last);
            }
            if (Now == null || Now == "")
            {
                m = new OsuGameStatusA("Unknown");
            }
            else
            {
                m = new OsuGameStatusA(Now);
            }
        }
    }
    [System.Serializable]
    partial class OsuGameStatusA
    {
        string Sta;
        public string Status { get => Sta; }
        public OsuGameStatusA(string s)
        {
            if (s != "Eiditing" && s != "Idle" && s != "MatchSetup" && s != "NoFoundProcess" && s != "Playing" && s != "Rank" && s != "SelectSong")
            {
                s = "Unknown";
            }
            Sta = s;
        }
        public static OsuGameStatusA
              Eiditing = new OsuGameStatusA("Eiditing"),
              Idle = new OsuGameStatusA("Idle"),
              Lobby = new OsuGameStatusA("Lobby"),
              MatchSetup = new OsuGameStatusA("MatchSetup"),
              ProcessNotFound = new OsuGameStatusA("NoFoundProcess"),
              Playing = new OsuGameStatusA("Playing"),
              Rank = new OsuGameStatusA("Rank"),
              SelectSong = new OsuGameStatusA("SelectSong"),
              Unknown = new OsuGameStatusA("Unknown");
        public static bool operator ==(OsuGameStatusA g, OsuGameStatusA s) => g.Status == s.Status || g.Status.Contains(s.Status);

        public static bool operator !=(OsuGameStatusA g, OsuGameStatusA s) => g.Status != s.Status || !g.Status.Contains(s.Status);
        public override bool Equals(object obj)
        {
            OsuGameStatusA gms = obj as OsuGameStatusA;
            if (gms != null && gms.Status == Status)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public override string ToString()
        {
            return Status;
        }
        public OsuGameStatus ToEnum()
        {
            return this == Eiditing ? OsuGameStatus.Eiditing :
                   this == Idle ? OsuGameStatus.Idle :
                   this == Lobby ? OsuGameStatus.Lobby :
                   this == MatchSetup ? OsuGameStatus.MatchSetup :
                   this == ProcessNotFound ? OsuGameStatus.ProcessNotFound :
                   this == Playing ? OsuGameStatus.Playing :
                   this == Rank ? OsuGameStatus.Rank :
                   this == SelectSong ? OsuGameStatus.SelectSong :
                   this == Unknown ? OsuGameStatus.Unknown : OsuGameStatus.Unknown;
        }
        public static bool operator ==(OsuGameStatusA g, OsuGameStatus c)
        {
            return g.ToEnum() == c;
        }
        public static bool operator !=(OsuGameStatusA g, OsuGameStatus c)
        {
            return g.ToEnum() != c;
        }
        public static bool operator ==(OsuGameStatus c, OsuGameStatusA g)
        {
            return g.ToEnum() == c;
        }
        public static bool operator !=(OsuGameStatus c, OsuGameStatusA g)
        {
            return g.ToEnum() != c;
        }
    }


}