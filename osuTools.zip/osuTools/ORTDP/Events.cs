﻿using Sync.Tools;
using System;
namespace osuTools
{
    using OsuRTDataProvider.Mods;
    partial class ORTDP
    {
        bool InDebugMode()
        {
            return DebugMode;
        }
        System.Timers.Timer timer1 = new System.Timers.Timer();            
        int cc = 0;
        int allhit;
        double persec = 0;
        void HitChanged()
        {
            System.Threading.Tasks.Task.Run(new Action(() =>
            {
                while (true)
                {
                   
                    if (GameMode.CurrentMode == OsuGameModeA.Mania)
                    {
                        allhit = c300g + c300 + c200 + c100 + c50 + cMiss;
                        System.Threading.Thread.Sleep(1000);
                        persec = ((c300g + c300 + c200 + c100 + c50 + cMiss) - allhit);
                    }
                    if (GameMode.CurrentMode == OsuGameModeA.Osu)
                    {
                        allhit = c300 + c100 + c50 + cMiss;
                        System.Threading.Thread.Sleep(1000);
                        persec = ((c300 + c100 + c50 + cMiss) - allhit);
                    }
                    if (GameMode.CurrentMode == OsuGameModeA.Catch)
                    {
                        allhit = c300 + c50 + cMiss;
                        System.Threading.Thread.Sleep(1000);//间隔0.5秒
                        persec = ((c300 + c50 + cMiss) - allhit);
                    }
                }
            }));

        }
        void InitLisenter()
        {
            //InfoReaderPlugin.InfoReader reader = new InfoReaderPlugin.InfoReader();
            p = new OsuRTDataProvider.OsuRTDataProviderPlugin();
            p.OnEnable();
            lm = p.ListenerManager;
            lm.OnCountGekiChanged += Lm_OnCountGekiChanged;
            lm.OnCount300Changed += Lm_OnCount300Changed;
            lm.OnCountKatuChanged += Lm_OnCountKatuChanged;
            lm.OnCount100Changed += Lm_OnCount100Changed;
            lm.OnCount50Changed += Lm_OnCount50Changed;
            lm.OnCountMissChanged += Lm_OnCountMissChanged;
            lm.OnComboChanged += Lm_OnComboChanged;
            lm.OnScoreChanged += Lm_OnScoreChanged;
            lm.OnPlayingTimeChanged += Lm_OnPlayingTimeChanged;
            lm.OnHealthPointChanged += Lm_OnHealthPointChanged;
            lm.OnAccuracyChanged += Lm_OnAccuracyChanged;
            lm.OnBeatmapChanged += Lm_OnBeatmapChanged;
            lm.OnModsChanged += Lm_OnModsChanged;
            lm.OnPlayModeChanged += Lm_OnPlayModeChanged;
            lm.OnStatusChanged += Lm_OnStatusChanged;
            lm.OnPlayerChanged += Lm_OnPlayerChanged;
            gm = new GMMode("???", "???",ref bp);
            gs = new GMStatus("???", "???");
            b = new Beatmaps.Beatmap();
        }

        private void Lm_OnPlayerChanged(string player)
        {
            pn = player.Trim();
        }

        void InitLisenter(OsuRTDataProvider.OsuRTDataProviderPlugin pl)
        {
            HitChanged();
            p = pl;
            lm = p.ListenerManager;
            lm.OnCountGekiChanged += Lm_OnCountGekiChanged;
            lm.OnCount300Changed += Lm_OnCount300Changed;
            lm.OnCountKatuChanged += Lm_OnCountKatuChanged;
            lm.OnCount100Changed += Lm_OnCount100Changed;
            lm.OnCount50Changed += Lm_OnCount50Changed;
            lm.OnCountMissChanged += Lm_OnCountMissChanged;
            lm.OnComboChanged += Lm_OnComboChanged;
            lm.OnScoreChanged += Lm_OnScoreChanged;
            lm.OnPlayingTimeChanged += Lm_OnPlayingTimeChanged;
            lm.OnHealthPointChanged += Lm_OnHealthPointChanged;
            lm.OnAccuracyChanged += Lm_OnAccuracyChanged;
            lm.OnBeatmapChanged += Lm_OnBeatmapChanged;
            lm.OnModsChanged += Lm_OnModsChanged;
            lm.OnPlayModeChanged += Lm_OnPlayModeChanged;
            lm.OnStatusChanged += Lm_OnStatusChanged;
            gm = new GMMode("???", "???",ref bp);
            gs = new GMStatus("???", "???");
            b = new Beatmaps.Beatmap();
        }
        int ijk = 0;
       // 
        private void Lm_OnPlayModeChanged(OsuRTDataProvider.Listen.OsuPlayMode last, OsuRTDataProvider.Listen.OsuPlayMode mode)
        {
            gm = new GMMode(last.ToString().Trim(), mode.ToString().Trim(),ref bp);
            // stars = bp.ModStarPair[(OsuGameMode)(mode)][0];
        }
        int modds;
        string longmod = "";
        private void Lm_OnModsChanged(ModsInfo mods)
        {
            longmod = mods.Name;
            mod = mods.ShortName;
            mo = new GMMod(mods.Name);
            unRanked = mods.HasMod(ModsInfo.Mods.AutoPilot) && mods.HasMod(ModsInfo.Mods.Autoplay) && mods.HasMod(ModsInfo.Mods.Relax) && mods.HasMod(ModsInfo.Mods.ScoreV2);
            Ranked = !unRanked;
            canfail = !mods.HasMod(ModsInfo.Mods.NoFail) && !mods.HasMod(ModsInfo.Mods.AutoPilot) && !mods.HasMod(ModsInfo.Mods.SpunOut) && !mods.HasMod(ModsInfo.Mods.Autoplay) && !mods.HasMod(ModsInfo.Mods.Relax);
            ManiaRanked = !mods.HasMod(ModsInfo.Mods.KeyCoop) && !mods.HasMod(ModsInfo.Mods.HardRock) && !mods.HasMod(ModsInfo.Mods.Random) && Ranked;
        }
        int bx = -1;
        OsuDB.OsuBeatmap bp;
        private void Lm_OnStatusChanged(OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus last_status, OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus status)
        {
            gs = new GMStatus(last_status.ToString().Trim(), status.ToString().Trim());
            if (last_status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.SelectSong)
            {
                bx = -1;
            }
            if (last_status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.Playing)
            {
                
                bx = bx == -1 ? (Ranked ? 1 : 0) : bx;
            }

            if (last_status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.Playing && status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.Rank && bx == 1)
            {
                ppc++;
                bx = -1;
            }
            if (GameStatus.CurrentStatus == OsuGameStatusA.Idle || GameStatus.CurrentStatus == OsuGameStatusA.SelectSong || GameStatus.CurrentStatus == OsuGameStatusA.Playing)
            {

                if (status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.Rank && last_status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.Playing && !Mods.Contains("Auto"))
                {
                    cc++;
                }
            }
            if (status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.SelectSong)
            {
                rt = 0;
                ijk = 0;
            }
            
            while (last_status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.Rank || status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.Playing || status == OsuRTDataProvider.Listen.OsuListenerManager.OsuStatus.SelectSong)
            {
                if (C300 != 0 || C300g != 0 || C200 != 0 || C100 != 0 || C50 != 0 || Cmiss != 0 || score != 0 || acc != 0)
                {
                    C300 = 0;
                    C300g = 0;
                    C200 = 0;
                    C100 = 0;
                    C50 = 0;
                    Cmiss = 0;
                    score = 0;
                    acc = 0;
                    Ranking = "???";
                }
                else
                {
                    break;
                }
                np = $"{b.Artist} - {b.Title} [{b.Difficulty}]";
                stars = b.Stars;
            }
            if (InDebugMode())
                IO.CurrentIO.Write($"[InfoReader] {last_status}({gs.LastStatus})->{status}({gs.CurrentStatus})");
        }
        void ReadByORTDP(OsuRTDataProvider.BeatmapInfo.Beatmap beatmap)
        {
            b = new Beatmaps.Beatmap(beatmap);
           
            np = b.ToString();
            System.Threading.Thread.Sleep(500);
            stars = b.Stars;
            dur =TimeSpan.FromMilliseconds(rtppi.BeatmapTuple.Duration);
        }
        Beatmaps.MD5String md5str = new Beatmaps.MD5String(), md5str1 = new Beatmaps.MD5String();
        void ReadByOsudb(OsuRTDataProvider.BeatmapInfo.Beatmap map)
        {
            if (md5str is null || md5str1 is null) throw new osuToolsException.osuToolsExceptionBase("Init MD5String Failed.");
            System.Security.Cryptography.MD5CryptoServiceProvider provider = new System.Security.Cryptography.MD5CryptoServiceProvider();
            provider.ComputeHash(System.IO.File.ReadAllBytes(file));
            md5str = new Beatmaps.MD5String(provider);
            if (md5str is null) throw new osuToolsException.osuToolsExceptionBase("MD5 calculation failed.");
            if (md5str1 is null) throw new osuToolsException.osuToolsExceptionBase("Init MD5String failed.");
            if (md5str != md5str1)
            {
                bd = new OsuDB.BaseDB();
                md5str1 = md5str;
            }


            try
            {
                string mD5 = Beatmaps.MD5String.GetString(new System.Security.Cryptography.MD5CryptoServiceProvider().ComputeHash(System.IO.File.ReadAllBytes(map.FilenameFull)));
                var beatmapa = bd.Beatmaps.FindByMD5(mD5);
                if (!(beatmapa is null))
                {
                    b = new Beatmaps.Beatmap(beatmapa);
                    bp = beatmapa;
                    np = b.ToString();
                    dur = beatmapa.TotalTime;
                    stars = beatmapa.ModStarPair[CurrentMode][0];
                }
                else
                {
                }
               
            }
            catch (osuToolsException.BeatmapNotFound)
            {
                Beatmaps.MD5String m5 = bd.GetMD5();
                bd = new OsuDB.BaseDB();
                Beatmaps.MD5String m51 = bd.GetMD5();
                if (m5 == m51)
                    ReadByORTDP(map);
                IO.CurrentIO.WriteColor("Can not find this beatmap by MD5 in osu!DataBase.Beatmap has read from osu file,Info may be correct after re-read OsuDataBase.", ConsoleColor.Red);
            }
        }
        private void Lm_OnBeatmapChanged(OsuRTDataProvider.BeatmapInfo.Beatmap map)
        {           
           try
            {
                if (beatmapreadmethod == BeatmapReadMethod.OsuRTDataProvider)
                {
                    ReadByORTDP(map);
                }
                if (beatmapreadmethod == BeatmapReadMethod.OsuDB)
                { 
                    ReadByOsudb(map);
                }                             
            }
            catch (Exception ex)
            {
                if(ex as System.Collections.Generic.KeyNotFoundException is null)
                    IO.CurrentIO.WriteColor($"[InfoReader] Exception:{ex.ToString()}", ConsoleColor.Red);
            }
        }
        private void Lm_OnCountGekiChanged(int hit)
        {
            C300g = hit;        }
        private void Lm_OnCount300Changed(int hit)
        {
            C300 = hit;
        }
        private void Lm_OnCountKatuChanged(int hit)
        {
            C200 = hit;
        }
        private void Lm_OnCount100Changed(int hit)
        {
            C100 = hit;
        }
        private void Lm_OnCount50Changed(int hit)
        {
            C50 = hit;
        }
        private void Lm_OnCountMissChanged(int hit)
        {
            Cmiss = hit;
        }
        private void Lm_OnComboChanged(int combo)
        {
            this.combo = combo;
            if (GameMode.CurrentMode == OsuGameModeA.Catch || GameMode.CurrentMode == OsuGameModeA.Osu)
            {
                if (combo == 3)
                {
                    dmp = (int)Score - 900;
                }
            }
        }
        private void Lm_OnPlayingTimeChanged(int ms)
        {
            if (ms != 0)
            {
                d = this;
            }
            double i = ms / rtppi.BeatmapTuple.Duration, k = 0;
            tmper = RealTimePPDisplayer.SmoothMath.SmoothDamp(tmper, i, ref k, 0.5, 0.033);
            tmper = ms / rtppi.BeatmapTuple.Duration;
            if (tmper > 1)
            {
                tmper = 1;
            }
            if (CurrentStatus != OsuGameStatus.Playing)
            {
                tmper = 0;
            }
            if (CurrentStatus == OsuGameStatus.Rank && LastStatus == OsuGameStatus.Playing) tmper = 1;
            time = ms;
        }
        private void Lm_OnScoreChanged(int obj)
        {
            try
            {
                double current = obj - score;
                double retryflag = 0;
                score = obj;
                bool ScoreZeroed = obj == 0;
                if (CurrentStatus == OsuGameStatusA.SelectSong)
                    retryflag++;
                if (ScoreZeroed && retryflag >= 0 && PlayerMaxCombo != 0)
                {
                    if (CurrentStatus != OsuGameStatusA.Rank)
                    {
                        if (InDebugMode())
                            IO.CurrentIO.WriteColor($"Retry at {time}ms", ConsoleColor.Yellow);
                        rt++;
                        OnRetry(this, rt);
                    }
                }
            }
            catch
            {

            }
        }
        private void Lm_OnHealthPointChanged(double hp)
        {
            this.hp = hp;
            bool NoFail = !CanFail;
            bool IsPlaying = gs.CurrentStatus == OsuGameStatusA.Playing && gs.LastStatus != OsuGameStatusA.Playing;
            bool ModsAreValid = !Mods.Contains("Unknown");

            if (hp <= 0 && Score > 0 && CanFail && IsPlaying && ModsAreValid)
            {
                OnFail(this);
            }
            if (hp <= 0 && Score > 0 && NoFail)
            {
                OnNoFail(this);
            }
        }
        private void Lm_OnAccuracyChanged(double acc)
        {
            this.acc = acc;
        }
    }
}