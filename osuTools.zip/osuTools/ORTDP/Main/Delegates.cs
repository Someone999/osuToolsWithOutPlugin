﻿namespace osuTools
{
    partial class ORTDP
    {
        public delegate void OnFailedHandler(ORTDP currentStatus);
        public event OnFailedHandler OnFail;
        public delegate void OnNoFailHandler(ORTDP currentStatus);
        public event OnNoFailHandler OnNoFail;
        public delegate void OnRetryHandler(ORTDP currentStatus, int timesofRetry);
        public event OnRetryHandler OnRetry;
    }
}