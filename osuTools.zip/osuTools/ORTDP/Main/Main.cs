﻿using System;

namespace osuTools
{
    [Serializable]
    public partial class ORTDP
    {
        public ORTDP()
        {
            bd = new OsuDB.BaseDB();
            InitLisenter();          
            System.Windows.Forms.Application.ThreadException += Application_ThreadException;
            System.AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            Sync.Tools.IO.CurrentIO.Write("ORTDP初始化完成");
            ppinfo = new SyncPPInfo("rtpp", null, null, this);
        }

        public ORTDP(OsuRTDataProvider.OsuRTDataProviderPlugin p)
        {
            bd = new OsuDB.BaseDB();
            InitLisenter(p);           
            System.Windows.Forms.Application.ThreadException += Application_ThreadException;
            Sync.Tools.IO.CurrentIO.Write("ORTDP初始化完成");
            ppinfo = new SyncPPInfo("rtpp", null, null, this);

        }
        public ORTDP(OsuRTDataProvider.OsuRTDataProviderPlugin p, RealTimePPDisplayer.RealTimePPDisplayerPlugin rp, InfoReaderPlugin.RtppdInfo d)
        {
            bd = new OsuDB.BaseDB();
            InitLisenter(p);            
            if (rp != null && d != null)
            {
                
                arp = rp;
                arp.RegisterDisplayer("my", (id) =>
                  {
                      d = new InfoReaderPlugin.RtppdInfo();
                      rtppi = (InfoReaderPlugin.RtppdInfo)d;
                      ppinfo = new SyncPPInfo("rtpp", arp, rtppi, this);
                      return d;
                  });
            }
            Sync.Tools.IO.CurrentIO.Write("ORTDP初始化完成");
            System.Windows.Forms.Application.ThreadException += Application_ThreadException;


        }
        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            System.IO.File.WriteAllText("osuToolsEx.txt", ((Exception)(e.ExceptionObject)).ToString());
        }
        private void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            System.IO.File.WriteAllText("osuToolsEx.txt", e.Exception.ToString());
        }
    }
}
