﻿namespace osuTools
{
    using System.IO;
    partial class ORTDP
    {
        /// <summary>
        /// 将本ORTPDP对象序列化。
        /// </summary>
        public void WriteToFile()
        {
            FileStream stream;
            if (!File.Exists("Ser.sed"))
                stream = File.Create("Ser.sed");
            else
                stream = File.Open("Ser.sed", FileMode.Open);
            System.Runtime.Serialization.Formatters.Binary.BinaryFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            formatter.Serialize(stream, this);
        }
        /// <summary>
        /// 将本ORTPDP对象反序列化。
        /// </summary>
        public static ORTDP ReadFromFile()
        {
            FileStream stream;
            if (!File.Exists("Ser.sed"))
                stream = File.Create("Ser.sed");
            else
                stream = File.Open("Ser.sed", FileMode.Open);
            System.Runtime.Serialization.Formatters.Binary.BinaryFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            return (ORTDP)formatter.Deserialize(stream);
        }
    }
}