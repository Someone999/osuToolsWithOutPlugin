﻿namespace osuTools
{
    using System;
    partial class ORTDP
    {
        int dmp = 0;
        double tmper = 0;
        int bests;
        double bestp;
        TimeSpan dur, cur;
        bool ManiaRanked = false;
        bool unRanked = false;
        OsuInfo info = new OsuInfo();
        string file;
        OsuDB.BaseDB bd;
        bool Ranked;
        [NonSerialized]
        public SyncPPInfo ppinfo;
        double stars;
        ORTDP d;
        GMMode gm;
        GMMod mo;
        GMStatus gs;
        int rt;
        string Ranking = "Unknown";
        Beatmaps.Beatmap b;
        [NonSerialized]
        InfoReaderPlugin.RtppdInfo rtppi;
        [NonSerialized]
        OsuRTDataProvider.Listen.OsuListenerManager lm;
        [NonSerialized]
        OsuRTDataProvider.OsuRTDataProviderPlugin p;
        int C300g = 0, C300 = 0, C200 = 0, C100 = 0, C50 = 0, Cmiss = 0, combo = 0, score = 0, time = 0, mco = 0, ppc = 0;
        public BeatmapReadMethod beatmapreadmethod=BeatmapReadMethod.OsuRTDataProvider;
        string pn = "";
        RealTimePPDisplayer.RealTimePPDisplayerPlugin arp;
        double acc, hp, maxpp, fcpp, scc = 0;
        string mod, np;
        bool canfail = false;
        public bool DebugMode { get; set; }
        public enum BeatmapReadMethod {OsuRTDataProvider,OsuDB}
    }
}