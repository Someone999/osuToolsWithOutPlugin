﻿namespace osuTools.Online
{

    [System.Serializable]
    public enum BeatmapStatus { Graveyard = -2, WIP, Pending, Ranked, Approved, Qualified, Loved, None = 2048 }
    [System.Serializable]
    public enum Genre { Any, Unspecified, VideoGame, Anime, Rock, Pop, Other, Novelty, HipHop = 9, Electronic }
    [System.Serializable]
    public enum Language { Any, Other, English, Japanese, Chinese, Instrumental, Korean, French, German, Swedish, Spanish, Italian }
}
