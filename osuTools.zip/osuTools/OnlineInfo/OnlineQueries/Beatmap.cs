﻿namespace osuTools
{
    namespace Online
    {
        using Newtonsoft.Json.Linq;
        using OsuRTDataProvider.BeatmapInfo;
        using System;
        using System.Collections.Generic;
        /// <summary>
        /// 在线获取的谱面的集合
        /// </summary>
        public class OnlineBeatmapCollection : OnlineInfo<OnlineBeatmap>
        {

            List<OnlineBeatmap> beatmaps = new List<OnlineBeatmap>();
            int pos = -1;
            int i = 0;
            public OnlineBeatmap this[int x]
            {
                get => beatmaps[x];
                set => beatmaps[x] = value;
            }
            public OnlineBeatmapCollection()
            {
                Sync.Tools.IO.CurrentIO.Write("OnlineBeatmaps Class");

            }
            public List<OnlineBeatmap> Beatmaps { get => beatmaps; }
            public int Count { get => beatmaps.Count; }
            public OnlineBeatmapCollection Find(string keyword)
            {
                OnlineBeatmapCollection bc = new OnlineBeatmapCollection();
                foreach (var beat in beatmaps)
                {
                    if (beat.GetLocalBeatmap().ToString().Trim().ToUpper().Contains(keyword.ToUpper().Trim()) ||
                        beat.GetLocalBeatmap().Source.Trim().ToUpper().Contains(keyword.ToUpper().Trim()) ||
                        beat.GetLocalBeatmap().Tags.Trim().ToUpper().Contains(keyword.ToUpper().Trim()))
                    {
                        bc.beatmaps.Add(beat);
                    }
                }
                return bc;
            }
            public bool Contains(OnlineBeatmap b) => beatmaps.Contains(b);

            public void AllParse(OsuApiQuery query)
            {


                if (query.QueryType != OsuApiQueryType.Beatmaps)
                {
                    throw new ArgumentException("请使用OsuApiQueryType.Beatmaps来获取谱面!");
                }
                var jarr = query.Query();

                var res = jarr.Children();
                foreach (var js in res)
                {
                    beatmaps.Add(new OnlineBeatmap((JObject)js));
                }
            }
            int posi = 0;
            public IEnumerator<OnlineBeatmap> GetEnumerator()
            {
                return beatmaps.GetEnumerator();

            }
        }
        /// <summary>
        /// 在线获取的谱面
        /// </summary>
        [Serializable]
        public partial class OnlineBeatmap : IEquatable<OnlineBeatmap>
        {
            public static bool operator ==(OnlineBeatmap olb, Beatmaps.Beatmap lob)
            {
                if (lob.BeatmapID == 0 || lob.BeatmapID == -1) throw new NotSupportedException();
                if (olb.BeatmapID == lob.BeatmapID && (lob.BeatmapID != 0 && lob.BeatmapID != -1)) return true;
                else return false;
            }
            public static bool operator !=(OnlineBeatmap olb, Beatmaps.Beatmap lob)
            {
                if (lob.BeatmapID == 0 || lob.BeatmapID == -1) throw new NotSupportedException();
                if (olb.BeatmapID == lob.BeatmapID && (lob.BeatmapID != 0 && lob.BeatmapID != -1)) return false;
                else return true;
            }
            public static bool operator ==(OnlineBeatmap olb, Beatmap lob)
            {
                if (lob.BeatmapID == 0 || lob.BeatmapID == -1) throw new NotSupportedException();
                if (olb.BeatmapID == lob.BeatmapID && (lob.BeatmapID != 0 && lob.BeatmapID != -1)) return true;
                else return false;
            }
            public static bool operator !=(OnlineBeatmap olb, Beatmap lob)
            {
                if (lob.BeatmapID == 0 || lob.BeatmapID == -1) throw new NotSupportedException();
                if (olb.BeatmapID == lob.BeatmapID && (lob.BeatmapID != 0 && lob.BeatmapID != -1)) return false;
                else return true;
            }
            public bool IsEmpty()
            {
                if (file_md5 == "0")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            public OnlineBeatmap(JObject jobj)
            {
                Parse(jobj);
            }
            void Parse(JObject jobj)
            {

                int.TryParse(jobj["beatmapset_id"].ToString(), out beatmapset_id);
                int.TryParse(jobj["beatmap_id"].ToString(), out beatmap_id);
                int.TryParse(jobj["approved"].ToString(), out approved);
                int.TryParse(jobj["total_length"].ToString(), out total_length);
                int.TryParse(jobj["hit_length"].ToString(), out hit_length);
                int.TryParse(jobj["mode"].ToString(), out mode);
                int.TryParse(jobj["count_normal"].ToString(), out count_normal);
                int.TryParse(jobj["count_slider"].ToString(), out count_slider);
                int.TryParse(jobj["count_spinner"].ToString(), out count_spinner);
                int.TryParse(jobj["creator_id"].ToString(), out creator_id);
                int.TryParse(jobj["genre_id"].ToString(), out genre_id);
                int.TryParse(jobj["language_id"].ToString(), out language_id);
                int.TryParse(jobj["playcount"].ToString(), out playcount);
                int.TryParse(jobj["passcount"].ToString(), out passcount);
                int.TryParse(jobj["favourite_count"].ToString(), out favourite_count);
                int.TryParse(jobj["max_combo"].ToString(), out max_combo);
                double.TryParse(jobj["diff_overall"].ToString(), out diff_overall);
                double.TryParse(jobj["diff_approach"].ToString(), out diff_approach);
                double.TryParse(jobj["diff_drain"].ToString(), out diff_drain);
                double.TryParse(jobj["diff_size"].ToString(), out diff_size);
                double.TryParse(jobj["bpm"].ToString(), out bpm);
                double.TryParse(jobj["rating"].ToString(), out rating);
                double.TryParse(jobj["diff_speed"].ToString(), out diff_speed);
                double.TryParse(jobj["diff_aim"].ToString(), out diff_aim);
                double.TryParse(jobj["difficultyrating"].ToString(), out difficultyrating);
                version = jobj["version"].ToString();
                file_md5 = jobj["file_md5"].ToString();
                submit_date = jobj["submit_date"].ToString();
                last_update = jobj["last_update"].ToString();
                approved_date = jobj["approved_date"].ToString();
                title = jobj["title"].ToString();
                artist = jobj["artist"].ToString();
                creator = jobj["creator"].ToString();
                tags = jobj["tags"].ToString();
                source = jobj["source"].ToString();
                status = (BeatmapStatus)(approved);
            }
            int beatmapset_id = -2;

            int beatmap_id = -2;
            BeatmapStatus status = BeatmapStatus.None;
            int approved = -1;
            int total_length = -1;
            int hit_length = -1;
            string version = "";
            string file_md5 = "0";
            double diff_size = -1;
            double diff_overall = -1;

            double diff_approach = -1;

            double diff_drain = -1;

            int mode = -1;

            int count_normal = -1;

            int count_slider = -1;

            int count_spinner = -1;

            string submit_date = "0-0-0 0:0:0";

            string approved_date = "0-0-0 0:0:0";

            string last_update = "0-0-0 0:0:0";

            string artist = "";

            string title = "";

            string creator = "";

            int creator_id = 0;

            double bpm = 0.0;

            string source = "";

            string tags = "";

            int genre_id = 0;

            int language_id = 0;

            int favourite_count = 0;

            double rating = 0.0;

            int download_unavailable = 0;

            int audio_unavailable = 0;

            int playcount = 0;

            int passcount = 0;

            int max_combo = 0;

            double diff_aim = 0.0;

            double diff_speed = 0.0;

            double difficultyrating = 0.0;
            public void Serialize()
            {
                var stream = new System.IO.FileStream($".\\beatmapinfo\\{beatmap_id}.sed", System.IO.FileMode.OpenOrCreate);
                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                binaryFormatter.Serialize(stream, this);
                stream.Close();
            }
            public static OnlineBeatmap Deserialize(int beatmap_id)
            {

                System.Runtime.Serialization.Formatters.Binary.BinaryFormatter binaryFormatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                return SerilazeTools.Deserialize<OnlineBeatmap>($".\\beatmapinfo\\{beatmap_id}.sed");
            }
            public override string ToString()
            {
                return $"{Artist} - {Title} [{Version}] ({tags})\nMode:{Mode.ToString()} Stars:{difficultyrating.ToString("f2")} BPM:{bpm}\nOD:{OD} AR:{AR} CS:{CS} HP:{HP}";
            }
            public Beatmaps.Beatmap GetLocalBeatmap()
            {
                return new Beatmaps.Beatmap(this);
            }
            bool IEquatable<OnlineBeatmap>.Equals(OnlineBeatmap other)
            {
                if (file_md5 == other.file_md5)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }
}