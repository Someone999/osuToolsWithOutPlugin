﻿namespace osuTools.Online
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    /// <summary>
    /// 代表一次在线查询，里面包含了所需的参数。
    /// </summary>
    [System.Serializable]
    public class OsuApiQuery
    {
        JArray arr;
        Uri i;
        string exc = "请检查网络是否通畅";
        public Uri QueryUri { get => i; }
        public int UserID { get; set; }
        public JArray JsonArray { get => arr; }
        OsuApiType t;
        public OsuApiQueryType QueryType { get => t.ToEnum(); set => t = new OsuApiType(value); }
        OsuGameModeA m = OsuGameModeA.Osu;
        public OsuGameMode Mode { get => m.ToEnum(); set => m = new OsuGameModeA((int)value); }
        string apikey;
        string user;
        public string UserName { get => user; set => user = value; }
        public int BeatmapID { get => beatmapid; set { if (value == -1) { beatmapid = 0; } else { beatmapid = value; } } }
        public string ApiKey { get => apikey; set { if (value.Length < 40 || value.Length > 40) { apikey = ""; throw new FormatException("请输入正确的ApiKey!"); } else apikey = value; } }
        int beatmapid = -2;
        public OsuApiQuery(JArray j)
        {
            arr = j;
        }
        public OsuApiQuery()
        {

        }
        public JArray Query()
        {
            //try
            {
                string temp = $"http://osu.ppy.sh/api/{t.ToString()}?k={ApiKey}";

                if (apikey == "")
                {
                    Sync.Tools.IO.CurrentIO.WriteColor("请先去osu.ppy.sh/p/api申请一个osuApiKey", ConsoleColor.Red);
                    return null;
                }
                apikey = ApiKey;
                if (QueryType == OsuApiQueryType.Beatmaps)
                {
                    if (beatmapid == -2)
                    {
                        Sync.Tools.IO.CurrentIO.WriteColor("请输入谱面ID", ConsoleColor.Red);
                        return null;
                    }
                    user = UserName;
                    beatmapid = BeatmapID;
                    if (beatmapid <= 0)
                    {
                        throw new ArgumentException("Beatmap is invalid.");
                    }
                    temp += $"&b={beatmapid}";
                }
                if(t.ToEnum()==OsuApiQueryType.UserInfomation)
                {
                    if(UserID==0)
                    {
                        if(UserName=="")
                        {
                            throw new ArgumentNullException("请输入用户名。");
                        }
                        else
                        {
                            temp += $"&u={UserName}&type=string";
                        }
                    }
                    else
                    {
                        temp += $"&u={UserID}&type=id";
                    }
                }
                if(t.ToEnum()==OsuApiQueryType.BestRecords||t.ToEnum()==OsuApiQueryType.RecentRecords||t.ToEnum()==OsuApiQueryType.Scores)
                {
                    if(UserName=="")
                    {
                        if(UserID==0)
                        {
                            throw new ArgumentNullException("Type the username.");
                        }
                        else
                        {
                            if (BeatmapID < 0) throw new ArgumentNullException("Invalid BeatmapID");
                            else temp += $"&u={UserID}&b={BeatmapID}&type=id";
                        }
                    }
                    else
                    {
                        if (BeatmapID < 0) throw new ArgumentNullException("Invalid BeatmapID");
                        else temp += $"&u={UserID}&b={BeatmapID}&type=string";
                    }
                }
                Uri u = new Uri(temp.ToString());
                i = u;
                if (u == null || i == null)
                {
                    throw new NullReferenceException("未能生成Uri");
                }
                Sync.Tools.IO.CurrentIO.Write("Connecting...");
                System.Net.Http.HttpClient c = new System.Net.Http.HttpClient();
                Sync.Tools.IO.CurrentIO.Write("Downloading data...");
                string js = c.GetStringAsync(u).Result;
                Sync.Tools.IO.CurrentIO.Write("Processing data...");
                JArray jarr = (JArray)JsonConvert.DeserializeObject(js);
                arr = jarr;
                if (QueryType == OsuApiQueryType.Beatmaps)
                {
                    exc += $"并检查谱面ID({beatmapid})是否正确。";
                }
                if (QueryType == OsuApiQueryType.BestRecords || QueryType == OsuApiQueryType.Scores || QueryType == OsuApiQueryType.RecentRecords)
                {
                    exc += $"并检查用户名({user})谱面ID({beatmapid})是否正确。";
                }
                if (QueryType == OsuApiQueryType.UserInfomation)
                {
                    exc += $"并检查用户名({user})是否正确。";
                }
                if (jarr.Count == 0)
                {
                    throw new osuToolsException.OnlineQueryFailed($"{exc}");
                }
                return jarr;
            }
            // catch (Exception c)
            {
                //Sync.Tools.IO.CurrentIO.WriteColor($"查询失败:{c.Message}", ConsoleColor.Red);
                return new JArray();
            }

        }
    }
}