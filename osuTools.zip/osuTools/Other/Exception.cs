﻿namespace osuTools
{

    using System;

    namespace osuToolsException
    {
        public class osuToolsExceptionBase : Exception
        {
            public osuToolsExceptionBase(string msg) : base(msg)
            {

            }
        }
        /// <summary>
        /// 当指定的文件不是谱面文件的时候引发的异常。
        /// </summary>
        public class InvalidBeatmapFile : osuToolsExceptionBase
        {
            public InvalidBeatmapFile(string msg) : base(msg)
            {

            }
        }
        /// <summary>
        /// osu!api查询失败时引发的异常。
        /// </summary>
        public class OnlineQueryFailed : osuToolsExceptionBase
        {
            public OnlineQueryFailed(string infom) : base(infom)
            {

            }
        }

        /// <summary>
        /// 处理osu文件时出现错误引发的异常，现已弃用。
        /// </summary>
        [Obsolete]
        public class FailToParse : osuToolsExceptionBase
        {
            public FailToParse(string message) : base(message)
            {

            }
        }
        /// <summary>
        /// 在指定的文件夹中找不到有效谱面时引发的异常。
        /// </summary>
        public class NoBeatmapInFolder : osuToolsExceptionBase
        {
            string f;
            public string Folder { get => f; }
            public NoBeatmapInFolder(string message, string folder) : base(message)
            {
                f = folder;
            }
        }
        /// <summary>
        /// 找不到与指定条件匹配的谱面时引发的异常。
        /// </summary>
        public class BeatmapNotFound : osuToolsExceptionBase
        {

            public BeatmapNotFound(string message) : base(message)
            {

            }
        }
        /// <summary>
        /// 在指定的文件夹中找不到回放时引发的异常。
        /// </summary>
        public class NoReplayInFolder : osuToolsExceptionBase
        {
            string f;
            public string Folder { get => f; }
            public NoReplayInFolder(string message, string folder) : base(message)
            {
                f = folder;
            }
        }
        /// <summary>
        /// 找不到与指定条件匹配的回放时引发的异常。
        /// </summary>
        public class ReplayWasNotFound : osuToolsExceptionBase
        {

            public ReplayWasNotFound(string message) : base(message)
            {

            }
        }



    }
}