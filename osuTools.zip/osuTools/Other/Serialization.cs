﻿namespace osuTools
{
    using System;
    using System.IO;
    using System.Runtime.Serialization;
    using System.Runtime.Serialization.Formatters.Binary;
    public class Binder<T> : SerializationBinder
    {
        public override Type BindToType(string assemblyName, string typeName)
        {
            return System.Reflection.Assembly.GetExecutingAssembly().GetType("OnlineBeatmap");
        }
    }
    public class SerilazeTools
    {
        public static void Serialize<T>(object obj, string FileName)
        {
            FileStream stream;
            string[] path = FileName.Split('\\');
            string replacedpath = FileName.Replace(path[path.Length - 1], "");
            if (!Directory.Exists(replacedpath))
                Directory.CreateDirectory(replacedpath);
            if (!File.Exists(FileName))
            {
                stream = new FileStream(FileName, FileMode.OpenOrCreate);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Binder = new Binder<T>();
                formatter.Serialize(stream, obj);
                stream.Close();
                return;
            }
            else
            {
                return;
            }
        }
        public static T Deserialize<T>(string FileName)
        {
            FileStream stream;
            stream = new FileStream(FileName, FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            T CurObj = (T)formatter.Deserialize(stream);
            stream.Close();
            return CurObj;
        }
    }
}